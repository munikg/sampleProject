package com.smartims.bms.cc;

public class CC {
	public static String insertSQL = "insert into bms values(?,?,?,?,?,?,?,?,?)";
	public static String searchSQL = "Select * from bms where Book_ID=?";
	public static String updateSQL = "update bms set Book_Price=? where Book_ID=?";
	public static String deleteSQL = "delete from bms where book_id=?";
	public static String searchByAuthorSQL = "Select * from bms where BOOK_AUTHOR=?";
	public static String searchByActiveSQL = "Select * from bms where IS_ACTIVE =?";
	public static String searchByNameSQL = "Select * from bms where Book_Name=?";
	public static String searchByPriceSQL = "select * from bms where book_price between ? and ?";
	public static String searchByItsStockSQL = "Select * from bms where IN_Stock=?";

}
