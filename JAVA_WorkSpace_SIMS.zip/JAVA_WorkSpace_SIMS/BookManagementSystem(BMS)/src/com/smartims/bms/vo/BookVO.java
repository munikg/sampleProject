package com.smartims.bms.vo;

public class BookVO {
	int bookID;
	String bookName;
	int publishYear;
	String bookAuthor;
	float bookPrice;
	String city;
	String zonar;
	boolean inStock;
     String active;
	public int getBookID() {
		return bookID;
	}

	public void setBookID(int bookID) {
		this.bookID = bookID;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public int getPublishYear() {
		return publishYear;
	}

	public void setPublishYear(int publishYear) {
		this.publishYear = publishYear;
	}

	public String getBookAuthor() {
		return bookAuthor;
	}

	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}

	public float getPrice() {
		return bookPrice;
	}

	public void setPrice(float bookPrice) {
		this.bookPrice = bookPrice;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getZonar() {
		return zonar;
	}

	public void setZonar(String zonar) {
		this.zonar = zonar;
	}

	public boolean isInStock() {
		return inStock;
	}

	public void setInStock(boolean inStock) {
		this.inStock = inStock;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

}
