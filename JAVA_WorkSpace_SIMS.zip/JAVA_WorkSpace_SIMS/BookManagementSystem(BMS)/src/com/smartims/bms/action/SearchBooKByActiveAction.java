package com.smartims.bms.action;

import java.util.Scanner;

import com.smartims.bms.dao.BookDAO;

public class SearchBooKByActiveAction {
	void searchIsActive() {
		BookDAO bdao = new BookDAO();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter YES OR NO For knownig Active And InActive Books :");

		String active = sc.next();
		bdao.searcByActive(active);

	}
	public static void main(String[] args) {
		SearchBooKByActiveAction sb=new SearchBooKByActiveAction();
		sb.searchIsActive();
	}
}
