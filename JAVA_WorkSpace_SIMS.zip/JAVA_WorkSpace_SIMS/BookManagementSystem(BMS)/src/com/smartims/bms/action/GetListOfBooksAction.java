package com.smartims.bms.action;

import com.smartims.bms.dao.BookDAO;

public class GetListOfBooksAction {
	public void getAllBooks() {

		BookDAO bdao=new BookDAO();
		bdao.listOfBooks();
		
	}
public static void main(String[] args) {
	GetListOfBooksAction ga=new GetListOfBooksAction();
	ga.getAllBooks();
}
}
