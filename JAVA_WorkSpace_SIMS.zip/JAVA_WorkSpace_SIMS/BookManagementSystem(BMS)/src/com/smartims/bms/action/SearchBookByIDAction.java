package com.smartims.bms.action;

import java.util.Scanner;

import com.smartims.bms.dao.BookDAO;

public class SearchBookByIDAction {
	
	BookDAO bdao=new BookDAO();
	void searchBook(){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Book ID to Search :");
		int BookId = sc.nextInt();
		bdao.searchBook(BookId);

	}
	public static void main(String[] args) {
		SearchBookByIDAction sba=new SearchBookByIDAction();
		sba.searchBook();
	}

}
