package com.smartims.bms.action;

import java.util.Scanner;

import com.smartims.bms.dao.BookDAO;

public class SearchBookByAuthor {
	public void searchAuthor() {
		BookDAO bdao = new BookDAO();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter AuthorName To Search Book");
		String author = sc.next();
		bdao.searchBookByAuthor(author);

	}
	public static void main(String[] args) {
		SearchBookByAuthor sba=new SearchBookByAuthor();
		sba.searchAuthor();
	}

}
