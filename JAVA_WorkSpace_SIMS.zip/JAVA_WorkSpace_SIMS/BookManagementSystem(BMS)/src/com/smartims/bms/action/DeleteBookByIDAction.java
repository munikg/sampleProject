package com.smartims.bms.action;

import java.util.Scanner;

import com.smartims.bms.dao.BookDAO;

public class DeleteBookByIDAction {
	BookDAO bdao=new BookDAO();
	public void deleteBookById(){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Book ID to Delete :");
		int BookId = sc.nextInt();
		bdao.deleteBook(BookId);

	}
	public static void main(String[] args) {
		DeleteBookByIDAction sba=new DeleteBookByIDAction();
		sba.deleteBookById();
	}
}
