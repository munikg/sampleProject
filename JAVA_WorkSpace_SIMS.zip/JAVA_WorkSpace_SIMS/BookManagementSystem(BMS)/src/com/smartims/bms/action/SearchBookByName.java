package com.smartims.bms.action;

import java.util.Scanner;

import com.smartims.bms.dao.BookDAO;

public class SearchBookByName {
 public void searchByName() {
	 BookDAO bdao = new BookDAO();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter BookName To Search :");

		String bookName = sc.next();
		bdao.searcByName(bookName);
 }
 public static void main(String[] args) {
	 SearchBookByName sn=new SearchBookByName();
	 sn.searchByName();
}
}
