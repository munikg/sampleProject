package com.smartims.bms.action;

import java.util.Scanner;

import com.smartims.bms.dao.BookDAO;

public class SearchBookByItsStock {

	
		public void searchBookByItsStock() {
		     BookDAO dao=new BookDAO();
	
			Scanner sc = new Scanner(System.in);
			System.out.println("Get records By Entering 1/0");
			int stock=sc.nextInt();
			dao.getAllBooksByStock(stock);
		}

		public static void main(String[] args) {
			SearchBookByItsStock b = new SearchBookByItsStock();
			b.searchBookByItsStock();
		}


	}

