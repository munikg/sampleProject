package com.smartims.bms.action;

import java.util.Scanner;

import com.smartims.bms.dao.BookDAO;

public class SearchBookByPrice {
	public void searchByPrice() {
		BookDAO bdao = new BookDAO();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Minimun Price :");
		int min=sc.nextInt();
		System.out.println("Enter MaximumPrice :");
		int max=sc.nextInt();
		bdao.searchBookByPrice(min,max);
	}

	public static void main(String[] args) {
		SearchBookByPrice sbp = new SearchBookByPrice();
		sbp.searchByPrice();
	}
}
