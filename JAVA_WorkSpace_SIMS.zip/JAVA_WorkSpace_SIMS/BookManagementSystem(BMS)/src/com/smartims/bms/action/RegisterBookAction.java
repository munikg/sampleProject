package com.smartims.bms.action;

import java.util.Scanner;

import com.smartims.bms.dao.BookDAO;
import com.smartims.bms.vo.BookVO;

public class RegisterBookAction {
	BookVO bvo = new BookVO();
	BookDAO bdao = new BookDAO();

	public void getBookDetails() {
		Scanner sc = new Scanner(System.in);
		do {
		System.out.println("Enter Book_Id :");
		bvo.setBookID(sc.nextInt());

		boolean res = bdao.checkForExistence(bvo.getBookID());

		if (res) {
			System.out.println("Book Alreay Existed with Book_ID :" + bvo.getBookID());

		} else {
			System.out.println("Enter Book_Name :");
			bvo.setBookName(sc.next());
			System.out.println("Enter Publish Year :");
			bvo.setPublishYear(sc.nextInt());
			System.out.println("Enter Author_Name :");
			bvo.setBookAuthor(sc.next());
			System.out.println("Enter Book Price :");
			bvo.setPrice(sc.nextFloat());
			System.out.println("Enter City :");
			bvo.setCity(sc.next());
			System.out.println("Enter Book Zonar :");
			bvo.setZonar(sc.next());
			System.out.println("IN_Stock :");
			bvo.setInStock(sc.nextBoolean());
			System.out.println(" Is_Active  :");
			bvo.setActive(sc.next());
		}
		
		bdao.insertBook(bvo);
		
		System.out.println("Do You Want continue Enter Y/N :");
		String option=sc.next();
		if(option.equalsIgnoreCase("y")) {
			RegisterBookAction rb = new RegisterBookAction();
			rb.getBookDetails();
		}
		else if(option.equalsIgnoreCase("n")) {
			System.out.println("Thank You For Registering ");
		}
		else {
			System.out.println("Select  Valid Option");
		}
		
		}while(false);
	}

	public static void main(String[] args) {
		RegisterBookAction rb = new RegisterBookAction();
		rb.getBookDetails();
	}

}
