package com.smartims.bms.action;

import java.util.Scanner;

import com.smartims.bms.dao.BookDAO;

public class UpdateBookAction {
	public void updateBook() {
		BookDAO bdao = new BookDAO();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter BookID :");
		int bookid = sc.nextInt();
		System.out.println("Enter price to update :");
		float bookPrice = sc.nextFloat();
		bdao.updateBook(bookid, bookPrice);
	}

	public static void main(String[] args) {
		UpdateBookAction ub = new UpdateBookAction();
		ub.updateBook();
	}
}
