package com.smartims.bms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;

import com.smartims.bms.cc.CC;
import com.smartims.bms.vo.BookVO;

public class BookDAO {
	public boolean checkForExistence(int BookId) {
		boolean flag = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "root");
			System.out.println("Connected to Database Successfully");
			PreparedStatement pstmt = con.prepareStatement(CC.searchSQL);
			pstmt.setInt(1, BookId);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public boolean checkForExistence(String active) {
		boolean flag = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "root");
			System.out.println("Connected to Database Successfully");
			PreparedStatement pstmt = con.prepareStatement(CC.searchByActiveSQL);
			pstmt.setString(1, active);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public void insertBook(BookVO bvo) {

		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "root");
			System.out.println("Connected to Database Successfully");
			PreparedStatement stmt = con.prepareStatement(CC.insertSQL);
			stmt.setInt(1, bvo.getBookID());
			stmt.setString(2, bvo.getBookName());
			stmt.setInt(3, bvo.getPublishYear());
			stmt.setString(4, bvo.getBookAuthor());
			stmt.setFloat(5, bvo.getPrice());
			stmt.setString(6, bvo.getCity());
			stmt.setString(7, bvo.getZonar());
			stmt.setBoolean(8, bvo.isInStock());
			stmt.setString(9, bvo.getActive());

			int rs = stmt.executeUpdate();
			if (rs > 0) {
				System.out.println(rs + "  inserted SuccessFully");
			} else {
				System.out.println("Failed to insert..");
			}

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void searchBook(int bookId) {
		boolean bookpresent = checkForExistence(bookId);
		if (bookpresent) {
			try {

				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "root");
				System.out.println("Connected to Database Successfully");
				PreparedStatement stmt = con.prepareStatement(CC.searchSQL);
				stmt.setInt(1, bookId);
				ResultSet rs = stmt.executeQuery();

				while (rs.next()) {
					System.out.println("BOOK_ID           :" + rs.getInt(1));
					System.out.println("BOOK_NAME        :" + rs.getString(2));
					System.out.println("PUBLISHYEAR       :" + rs.getInt(3));
					System.out.println("BOOK_AUTHOR       :" + rs.getString(4));
					System.out.println("PRICE             :" + rs.getFloat(5));
					System.out.println("CITY              :" + rs.getString(6));
					System.out.println("ZONAR             :" + rs.getString(7));
					System.out.println("IN_STOCK          :" + rs.getBoolean(7));
					System.out.println("IS_ACTIVE         :" + rs.getString(7));
					System.out.println("<---------------------------------------->");

				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else {
			System.out.println("Book not found with" + bookId);
		}
	}

	public void deleteBook(int bookId) {
		boolean present = checkForExistence(bookId);
		if (present) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "root");
				System.out.println("Connected to Database Successfully");

				PreparedStatement stmt = con.prepareStatement(CC.deleteSQL);
				stmt.setInt(1, bookId);
				int i = stmt.executeUpdate();

				if (i > 0) {
					System.out.println("Book deleted succesfully with BooK_ID :" + bookId);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else {
			System.out.println("Book is not found");
		}
	}

	public void listOfBooks() {

		ArrayList bookRecordsList = new ArrayList();

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training?autoReconnect=true&useSSL=false", "root", "root");

			System.out.println("Connected to Database Successfully");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from bms ");

			while (rs.next()) {
				BookVO bv = new BookVO();
				bv.setBookID(rs.getInt(1));
				bv.setBookName(rs.getString(2));

				bv.setPublishYear(rs.getInt(3));
				bv.setBookAuthor(rs.getString(4));
				bv.setPrice(rs.getFloat(5));
				bv.setCity(rs.getString(6));
				bv.setZonar(rs.getString(7));
				bv.setInStock(rs.getBoolean(8));
				bv.setActive(rs.getString(9));

				bookRecordsList.add(bv);

			}
			// bookRecordsList.clear(); for clearing the arraylist data
			if (bookRecordsList.size() == 0) {
				System.out.println("No Books Found to Fetch..");
			} else {
				Iterator itr = bookRecordsList.iterator();
				while (itr.hasNext()) {
					BookVO bvo = (BookVO) itr.next();
					System.out.println(bvo.getBookID() + "----" + bvo.getBookName() + "----" + bvo.getPublishYear()
							+ "----" + bvo.getBookAuthor() + "----" + bvo.getPrice() + "----" + bvo.getCity() + "----"
							+ bvo.getZonar() + "----" + bvo.isInStock() + "----  " + bvo.getActive());
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void updateBook(int bookid, float bookPrice) {
		boolean idPresent = checkForExistence(bookid);
		if (idPresent) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "root");
				// System.out.println("Connected to Database Successfully");

				PreparedStatement stmt = con.prepareStatement(CC.updateSQL);

				stmt.setFloat(1, bookPrice);
				stmt.setInt(2, bookid);
				int i = stmt.executeUpdate();

				if (i > 0) {
					System.out.println("Book updated succesfully with Book Price :" + bookPrice);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else {
			System.out.println("BookID Is Not Found For Updation with ID :" + bookid);
		}

	}

	public void searchBookByAuthor(String author) {

		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "root");
			System.out.println("Connected to Database Successfully");

			PreparedStatement stmt = con.prepareStatement(CC.searchByAuthorSQL);
			stmt.setString(1, author);

			ResultSet rs1 = stmt.executeQuery();

			if (rs1.next()) {
				PreparedStatement stmt1 = con.prepareStatement(CC.searchByAuthorSQL);
				stmt1.setString(1, author);

				ResultSet rs = stmt1.executeQuery();
				ResultSetMetaData rm = rs.getMetaData();
				int count = rm.getColumnCount();
				for (int i = 1; i <= count; i++) {
					System.out.print(rm.getColumnName(i) + "      ");
				}
				System.out.println();
				while (rs.next()) {
					for (int i = 1; i <= count; i++) {
						System.out.print(rs.getString(i) + "           ");
					}
					System.out.println();
				}

			} else {
				System.out.println("No Author Found..");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void searcByActive(String active) {
		boolean present = checkForExistence(active);
		if (present) {
			try {

				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "root");
				// System.out.println("Connected to Database Successfully");

				PreparedStatement stmt1 = con.prepareStatement(CC.searchByActiveSQL);
				stmt1.setString(1, active);

				ResultSet rs = stmt1.executeQuery();

				ResultSetMetaData rm = rs.getMetaData();
				int count = rm.getColumnCount();
				for (int i = 1; i <= count; i++) {
					System.out.print(rm.getColumnName(i) + "      ");
				}
				System.out.println();
				while (rs.next()) {
					for (int i = 1; i <= count; i++) {
						System.out.print(rs.getString(i) + "           ");
					}
					System.out.println();
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

		} else {
			System.out.println("No Books Found..");
		}
	}

	public void searcByName(String bookName) {
		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "root");
			System.out.println("Connected to Database Successfully");

			PreparedStatement stmt = con.prepareStatement(CC.searchByNameSQL);
			stmt.setString(1, bookName);

			ResultSet rs1 = stmt.executeQuery();

			if (rs1.next()) {
				PreparedStatement stmt1 = con.prepareStatement(CC.searchByNameSQL);
				stmt1.setString(1, bookName);

				ResultSet rs = stmt1.executeQuery();
				ResultSetMetaData rm = rs.getMetaData();
				int count = rm.getColumnCount();
				for (int i = 1; i <= count; i++) {
					System.out.print(rm.getColumnName(i) + "      ");
				}
				System.out.println();
				while (rs.next()) {
					for (int i = 1; i <= count; i++) {
						System.out.print(rs.getString(i) + "               ");
					}
					System.out.println();
				}

			} else {
				System.out.println("No Book Found..");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void searchBookByPrice(int min, int max) {
		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "root");
			System.out.println("Connected to Database Successfully");

			PreparedStatement stmt = con.prepareStatement(CC.searchByPriceSQL);
			stmt.setInt(1, min);
			stmt.setInt(2, max);
			ResultSet rs1 = stmt.executeQuery();

			if (rs1.next()) {
				PreparedStatement stmt1 = con.prepareStatement(CC.searchByPriceSQL);

				stmt1.setInt(1, min);
				stmt1.setInt(2, max);
				ResultSet rs = stmt1.executeQuery();
				ResultSetMetaData rm = rs.getMetaData();
				int count = rm.getColumnCount();
				for (int i = 1; i <= count; i++) {
					System.out.print(rm.getColumnName(i) + "      ");
				}
				System.out.println();
				while (rs.next()) {
					for (int i = 1; i <= count; i++) {
						System.out.print(rs.getString(i) + "           ");
					}
					System.out.println();
				}

			} else {
				System.out.println("no books found with enter range of price.");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void getAllBooksByStock(int stock) {
		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "root");
			System.out.println("Connected to Database Successfully");

			PreparedStatement stmt = con.prepareStatement(CC.searchByItsStockSQL);
			stmt.setInt(1, stock);

			ResultSet rs1 = stmt.executeQuery();

			if (rs1.next() == true) {
				PreparedStatement stmt1 = con.prepareStatement(CC.searchByItsStockSQL);

				stmt1.setInt(1, stock);

				ResultSet rs = stmt1.executeQuery();
				ResultSetMetaData rm = rs.getMetaData();
				int count = rm.getColumnCount();
				for (int i = 1; i <= count; i++) {
					System.out.print(rm.getColumnName(i) + "      ");
				}
				System.out.println();
				while (rs.next()) {
					for (int i = 1; i <= count; i++) {
						System.out.print(rs.getString(i) + "               ");
					}
					System.out.println();
				}

			} else {
				System.out.println("NO Stock is there");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
