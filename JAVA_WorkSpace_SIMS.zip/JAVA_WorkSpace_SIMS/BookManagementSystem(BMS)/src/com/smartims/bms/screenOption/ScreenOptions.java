package com.smartims.bms.screenOption;

import java.util.Scanner;

import com.smartims.bms.action.DeleteBookByIDAction;
import com.smartims.bms.action.GetListOfBooksAction;
import com.smartims.bms.action.RegisterBookAction;
import com.smartims.bms.action.SearchBookByAuthor;
import com.smartims.bms.action.SearchBookByName;
import com.smartims.bms.action.SearchBookByPrice;
import com.smartims.bms.action.UpdateBookAction;

public class ScreenOptions {
	void screen() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Select Your Favorite Option Below");
		System.out.println("1.Register Book"+'\n'+"2.DeleteBookBYId"+'\n'+"3.Update Book"+'\n'+"4.GetListOfBooks"+'\n'+"5.Search BooK ByAuthor"+'\n'+"6.Search Book By Name"+'\n'+"7.Search Book By Price"+'\n'+"8.Cancel");
		System.out.println("Please Enter Option Number :");

		int option = sc.nextInt();

		switch (option) {
		case 1:
			RegisterBookAction rb = new RegisterBookAction();
			rb.getBookDetails();
			break;

		case 2:
			DeleteBookByIDAction d = new DeleteBookByIDAction();
			d.deleteBookById();
			break;
		case 3:
			UpdateBookAction ub=new UpdateBookAction();
			ub.updateBook();
			break;
		case 4:
			GetListOfBooksAction gb=new GetListOfBooksAction();
			gb.getAllBooks();
			break;
		case 5:
			SearchBookByAuthor sba=new SearchBookByAuthor();
			sba.searchAuthor();
			break;
		case 6:
			SearchBookByName sn=new SearchBookByName();
			sn.searchByName();
			break;
		case 7:
			SearchBookByPrice sp=new SearchBookByPrice();
			sp.searchByPrice();
			break;
		case 8:
			System.out.println("Thank You For Visiting");
			break;
		default:
          System.out.println("Enter Valid Option");
		}
	}
	public static void main(String[] args) {
		ScreenOptions so=new ScreenOptions();
		so.screen();
	}

}
