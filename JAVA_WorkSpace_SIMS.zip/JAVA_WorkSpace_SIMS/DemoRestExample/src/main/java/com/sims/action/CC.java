package com.sims.action;

public class CC {

	public static final String BookBYIdSQL = "select * from bms where BOOK_ID = ?";
	public static final String BookBYAuthorSQL = "select * from bms where Author = ?";
	public static final String BookBYActiveSQL = "select * from bms where IS_ACTIVE = ?";
	public static final String BookBYStockSQL = "select * from bms where IN_STOCK = ?";
	public static final String BookBYPriceRangeSQL = "select * from bms where BOOK_PRICE between ? and ?";
	public static final String DeleteBookIDSQL = "delete from bms where BOOK_ID = ?";
	public static final String BookBYCitySQL = "select * from bms where city = ?";
	public static final String BookBYGenereSQL = "select * from bms where BOOK_GENERE = ?";
	public static final String insertBookSQL = "insert into bms values(?,?,?,?,?,?,?,?,?)";
	public static final String listOfBooksSQL = "select * from bms";

}
