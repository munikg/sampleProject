package com.sims.policymanagementsystem.screenoption;

import java.util.Scanner;

import com.sims.policymanagementsystem.action.AdminLoginAction;
import com.sims.policymanagementsystem.action.AdminRegistrationAction;
import com.sims.policymanagementsystem.action.UnderWriterLogin;
import com.sims.policymanagementsystem.action.UserLoginAction;
import com.sims.policymanagementsystem.action.UserRegistrationAction;


public class ScreenOptions {
	 public void screen() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Welome to Insurance Management System");
		System.out.println("1.UserRegistration"+'\n'+"2.UnderWriterLogin"+'\n'+"3.UserLogin"+'\n'+"4.Exit");
		System.out.println("Please Enter Option Number :");
		
		int option = sc.nextInt();
		
		switch (option) {
		case 1:
			UserRegistrationAction ur=new UserRegistrationAction();
			ur.userRegistration();
			break;

		case 2:
			UnderWriterLogin uwl=new  UnderWriterLogin();
			uwl.uWLogin();
			break;
		case 3:
			UserLoginAction ul=new UserLoginAction();
			ul.user();
			break;
		case 4:
			AdminLoginAction al=new AdminLoginAction();
			al.admin();
			break;
		case 5:
			System.out.println("Thankyou For Visiting..");
			break;
		default:
          System.out.println("Enter Valid Option");
		}

		/*System.out.println("Do you want to continue Enter Y/N :");
		String choice=sc.next();
		if(choice.equalsIgnoreCase("y")) {
			ScreenOptions so=new ScreenOptions();
			so.screen();

		}
		else if(choice.equalsIgnoreCase("n")) {
			System.out.println("Thank You For Visiting ");
		}
		else {
			System.out.println("Select  Valid Option");
		}*/
		
	}
	public static void main(String[] args) {
		ScreenOptions so=new ScreenOptions();
		so.screen();
	}

}
