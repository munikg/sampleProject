package com.sims.policymanagementsystem.action;

import java.util.Scanner;

import com.sims.policymanagementsystem.dao.InsuranceDAO;
import com.sims.policymanagementsystem.vo.PolicyHolderVO;

public class PolicyHolderAction {
	PolicyHolderVO pv=new PolicyHolderVO();
	InsuranceDAO idao=new InsuranceDAO();
	public void policyHolder() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter The User_Id");
		pv.setUserID(sc.nextInt());
		System.out.println("Enter The Name Of the Holder");
		pv.setName(sc.next());
		System.out.println("Enter the adress Of Policy Holder");
		pv.setAdress(sc.next());
		System.out.println("Enter the phone Number ");
		pv.setPhoneNumber(sc.next());
		System.out.println("Enter The resenditial number ");
		pv.setResidentialNumber(sc.next());
		System.out.println("Enter The Email ID");
		pv.setEmailId(sc.next());
		System.out.println("Enter The profession ");
		pv.setProfession(sc.next());
		System.out.println("Enter Your Product Name ");
		pv.setProductName(sc.next());
		System.out.println("Enter Period of insurance");
		pv.setPeriodOfInsurance(sc.next());
		idao.policyHolderDetails(pv);
	}
	public static void main(String[] args) {
		PolicyHolderAction pa=new PolicyHolderAction();
		pa.policyHolder();
	}

}
