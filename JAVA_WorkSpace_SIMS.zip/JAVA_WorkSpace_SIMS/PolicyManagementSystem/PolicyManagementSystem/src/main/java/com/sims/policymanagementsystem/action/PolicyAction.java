package com.sims.policymanagementsystem.action;

import java.util.Scanner;

import com.sims.policymanagementsystem.dao.InsuranceDAO;
import com.sims.policymanagementsystem.vo.PolicyVO;

public class PolicyAction {
	InsuranceDAO idao=new InsuranceDAO();
	   PolicyVO po=new PolicyVO();
		public void policyDetails() {
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter Policy Details");
			System.out.println("Enter policy number");
			po.setPolicyNumber(sc.next());
			System.out.println("Enter period of insurace");
			po.setPeriodOfInsurance(sc.next());
			System.out.println("Enter insured Name");
			po.setInsuredName(sc.next());
			System.out.println("Enter insured Address");
			po.setInsuredAddress(sc.next());
			System.out.println("Enter Product");
			po.setProduct(sc.next());
			System.out.println("Enter issued On date in the format of DD/MM/YYYY");
			po.setPolicyIssuedOn(sc.next());
			System.out.println("Enter Premium of insurace");
			po.setPremium(sc.nextFloat());
			System.out.println("Enter premium payer userId");
			po.setUserID(sc.nextInt());
			System.out.println("Enter Policy Status");
			po.setPolicyStatus(sc.next());
			System.out.println("Enter Policy Holder State");
			po.setPolicyHolderState(sc.next());
			idao.addPolicy(po);
		}
		
}
