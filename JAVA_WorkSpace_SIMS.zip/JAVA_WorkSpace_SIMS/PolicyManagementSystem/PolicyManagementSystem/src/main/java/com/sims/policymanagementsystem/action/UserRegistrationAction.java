package com.sims.policymanagementsystem.action;

import java.util.Scanner;

import com.sims.policymanagementsystem.dao.InsuranceDAO;
import com.sims.policymanagementsystem.vo.UserVO;

public class UserRegistrationAction {
	UserVO uvo = new UserVO();

	public void userRegistration() {
		InsuranceDAO idao = new InsuranceDAO();
		Scanner sc = new Scanner(System.in);

		System.out.println("Register And Continue......");
		System.out.println("Enter First Name : ");
		uvo.setFirstName(sc.next());
		System.out.println("Enter Last Name :");
		uvo.setLastname(sc.next());
		System.out.println("Enter Age :");
		uvo.setAge(sc.nextInt());
		System.out.println("Enter Gender :");
		uvo.setGender(sc.next());
		System.out.println("Enter Contact Number :");
		uvo.setContactNumber(sc.next());
		System.out.println("Set User Id :");
		uvo.setUserID(sc.nextInt());
		System.out.println("Set password :");
		uvo.setPassword(sc.next());

		idao.userRegistration(uvo);

	}

}
