package com.sims.policymanagementsystem.action;

import java.util.Scanner;

import com.sims.policymanagementsystem.dao.InsuranceDAO;

public class UnderWriterLogin {
	InsuranceDAO idao=new InsuranceDAO();
   public void uWLogin() {
	   Scanner sc=new Scanner(System.in);
	   System.out.println("Enter UnderWriterID :");
	  int id=sc.nextInt();
	  System.out.println("Enter UnderWriter Password :");
	  String password=sc.next();
	  idao.underWriterLogin(id,password);
   }
   
}
