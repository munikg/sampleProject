package com.sims.policymanagementsystem.action;

import java.util.Scanner;

import com.sims.policymanagementsystem.dao.InsuranceDAO;

public class UserLoginAction {
	public void user() {
		
		InsuranceDAO idao = new InsuranceDAO();

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter User_ID :");
		int userID = sc.nextInt();
		System.out.println("Enter Password  :");
		String password = sc.next();

		idao.userLogin(userID, password);

	}

}
