package com.sims.policymanagementsystem.vo;

public class CoveragesVO {
	int userID;
	String autoLiabilityCoverage;
	String uninsuredAndUnderinsuredMotoristCoverage;
	String comprehensiveCoverage;
	String collisionCoverage;
	String medicalPaymentsCoverage;
	String personalInjuryProtection;
    int premium;

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getAutoLiabilityCoverage() {
		return autoLiabilityCoverage;
	}

	public void setAutoLiabilityCoverage(String autoLiabilityCoverage) {
		this.autoLiabilityCoverage = autoLiabilityCoverage;
	}

	public String getUninsuredAndUnderinsuredMotoristCoverage() {
		return uninsuredAndUnderinsuredMotoristCoverage;
	}

	public void setUninsuredAndUnderinsuredMotoristCoverage(String uninsuredAndUnderinsuredMotoristCoverage) {
		this.uninsuredAndUnderinsuredMotoristCoverage = uninsuredAndUnderinsuredMotoristCoverage;
	}

	public String getComprehensiveCoverage() {
		return comprehensiveCoverage;
	}

	public void setComprehensiveCoverage(String comprehensiveCoverage) {
		this.comprehensiveCoverage = comprehensiveCoverage;
	}

	public String getCollisionCoverage() {
		return collisionCoverage;
	}

	public void setCollisionCoverage(String collisionCoverage) {
		this.collisionCoverage = collisionCoverage;
	}

	public String getMedicalPaymentsCoverage() {
		return medicalPaymentsCoverage;
	}

	public void setMedicalPaymentsCoverage(String medicalPaymentsCoverage) {
		this.medicalPaymentsCoverage = medicalPaymentsCoverage;
	}

	public String getPersonalInjuryProtection() {
		return personalInjuryProtection;
	}

	public void setPersonalInjuryProtection(String personalInjuryProtection) {
		this.personalInjuryProtection = personalInjuryProtection;
	}

	public int getPremium() {
		return premium;
	}

	public void setPremium(int premium) {
		this.premium = premium;
	}
	

}
