package com.sims.policymanagementsystem.vo;

public class DriverVO {
	int userId;
	String driverName;
	String licenseNO;
	String licenseIssueDate;
	String licenseExPiryDate;
	int DrivingExperience;
	int DriverAge;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public String getLicenseNO() {
		return licenseNO;
	}

	public void setLicenseNO(String licenseNO) {
		this.licenseNO = licenseNO;
	}

	public String getLicenseIssueDate() {
		return licenseIssueDate;
	}

	public void setLicenseIssueDate(String licenseIssueDate) {
		this.licenseIssueDate = licenseIssueDate;
	}

	public String getLicenseExPiryDate() {
		return licenseExPiryDate;
	}

	public void setLicenseExPiryDate(String licenseExPiryDate) {
		this.licenseExPiryDate = licenseExPiryDate;
	}

	public int getDrivingExperience() {
		return DrivingExperience;
	}

	public void setDrivingExperience(int drivingExperience) {
		DrivingExperience = drivingExperience;
	}

	public int getDriverAge() {
		return DriverAge;
	}

	public void setDriverAge(int driverAge) {
		DriverAge = driverAge;
	}

}
