package com.sims.policymanagementsystem.vo;

public class PolicyVO {
	String policyNumber;
	String periodOfInsurance;
	String insuredName;
	String insuredAddress;
	String product;
	String policyIssuedOn;
	float premium;
	int userID;
	String policyStatus;
	String PolicyHolderState;
	public String getPolicyNumber() {
		return policyNumber;
	}
	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}
	public String getPeriodOfInsurance() {
		return periodOfInsurance;
	}
	public void setPeriodOfInsurance(String periodOfInsurance) {
		this.periodOfInsurance = periodOfInsurance;
	}
	public String getInsuredName() {
		return insuredName;
	}
	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}
	public String getInsuredAddress() {
		return insuredAddress;
	}
	public void setInsuredAddress(String insuredAddress) {
		this.insuredAddress = insuredAddress;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getPolicyIssuedOn() {
		return policyIssuedOn;
	}
	public void setPolicyIssuedOn(String policyIssuedOn) {
		this.policyIssuedOn = policyIssuedOn;
	}
	public float getPremium() {
		return premium;
	}
	public void setPremium(float premium) {
		this.premium = premium;
	}
	
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public String getPolicyStatus() {
		return policyStatus;
	}
	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}
	public String getPolicyHolderState() {
		return PolicyHolderState;
	}
	public void setPolicyHolderState(String policyHolderState) {
		PolicyHolderState = policyHolderState;
	}

}
