package com.sims.policymanagementsystem.action;

import java.util.Scanner;

import com.sims.policymanagementsystem.dao.InsuranceDAO;
import com.sims.policymanagementsystem.vo.CoveragesVO;

public class SelectCoveragesActions {
	CoveragesVO cvo = new CoveragesVO();
	InsuranceDAO idao = new InsuranceDAO();
	Scanner sc = new Scanner(System.in);

	public void coverages() {
		System.out.println("Enter the customer id");
		cvo.setUserID(sc.nextInt());
		System.out.println("Hey Enter YES/NO For Opting The Coverages");
		System.out.println("Do You Want AutoLiability Coverage...Amount=1000");
	    String res=sc.next();
	    if(res.equalsIgnoreCase("y")) {
		cvo.setAutoLiabilityCoverage("1000");
	    }
		System.out.println("Do You Want uninsured And Underinsured Motorist Coverage...Amount=1000");
		cvo.setUninsuredAndUnderinsuredMotoristCoverage(sc.next());
		System.out.println("Do You Want comprehensive Coverage...Amount=1000");
		cvo.setComprehensiveCoverage(sc.next());
		System.out.println("Do You Want collision Coverage...Amount=1000");
		cvo.setCollisionCoverage(sc.next());
		System.out.println("Do You Want medicalPayments Coverage...Amount=1000");
		cvo.setMedicalPaymentsCoverage(sc.next());
		System.out.println("Do You Want personal Injury Coverage...Amount=1000");
		cvo.setPersonalInjuryProtection(sc.next());
		int premium = 6000;
		System.out.println("Select Deductibles below :");
		System.out.println("1000/2500/3000");
		System.out.println("Enter Deductible");
		int deductible = sc.nextInt();
		System.out.println("Deductibles" + deductible);
		int totalPremium = premium - deductible;
		System.out.println("Your Total premium is" + totalPremium);
		cvo.setPremium(totalPremium);
		idao.coveragesOpted(cvo);
	}

	public static void main(String[] args) {
		SelectCoveragesActions sa = new SelectCoveragesActions();
		sa.coverages();
	}

}
