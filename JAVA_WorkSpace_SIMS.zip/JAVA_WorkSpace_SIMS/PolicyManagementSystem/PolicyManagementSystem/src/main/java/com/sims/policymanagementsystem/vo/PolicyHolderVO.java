package com.sims.policymanagementsystem.vo;

public class PolicyHolderVO {
    int userID;
	String name;
	String adress;
	String phoneNumber;
	String residentialNumber;
	String emailId;
	String profession;
	String productName;
	String periodOfInsurance;
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getResidentialNumber() {
		return residentialNumber;
	}
	public void setResidentialNumber(String residentialNumber) {
		this.residentialNumber = residentialNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getProfession() {
		return profession;
	}
	public void setProfession(String profession) {
		this.profession = profession;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getPeriodOfInsurance() {
		return periodOfInsurance;
	}
	public void setPeriodOfInsurance(String periodOfInsurance) {
		this.periodOfInsurance = periodOfInsurance;
	}
	

}
