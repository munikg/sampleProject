package com.sims.policymanagementsystem.action;

import java.util.Scanner;

import com.sims.policymanagementsystem.dao.InsuranceDAO;
import com.sims.policymanagementsystem.vo.DriverVO;

public class DriverDetailsAction {

	DriverVO dvo = new DriverVO();
	InsuranceDAO idao = new InsuranceDAO();

	public void driverDetails() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter UserID :");
		int id = sc.nextInt();
		dvo.setUserId(id);
		System.out.println("Enter driver Name :");
		String name = sc.next();
		dvo.setDriverName(name);
		System.out.println("Enter License Number :");
		String lnum = sc.next();
		dvo.setLicenseNO(lnum);

		System.out.println("Enter License issued Date in the form of DD/MM/YYYY :");
		String ldate = sc.next();
		dvo.setLicenseIssueDate(ldate);
		System.out.println("Enter License Expiry Date  in the form of DD/MM/YYYY ::");
		String vm = sc.next();
		dvo.setLicenseExPiryDate(vm);
		System.out.println("Enter Driving Experince :");
		int de = sc.nextInt();
         dvo.setDriverAge(de);
		System.out.println("Enter Driver Age:");
		int age = sc.nextInt();

		dvo.setDriverAge(age);

		idao.addDetailsOfDriver(dvo);
		System.out.println("Do You want add another Driver Enter Y/N :");
		String choice = sc.next();
		if (choice.equalsIgnoreCase("y")) {

			this.driverDetails();

		} else if (choice.equalsIgnoreCase("n")) {
			System.out.println("Thank You For Adding Driving Details.. ");
		} else {
			System.out.println("Select  Valid Option");
		}

	}

	

	public static void main(String[] args) {
		DriverDetailsAction da = new DriverDetailsAction();
		da.driverDetails();
	}
}
