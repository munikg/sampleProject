package com.sims.policymanagementsystem.cc;

public class CC {
	public static String userRegisrtationSQL = "insert into user values(?,?,?,?,?,?,?)";
	public static String usersearchSQL = "select * from user where user_Id=? and password=?";
	public static String adminRegisrtationSQL = "insert into admin values(?,?,?,?,?,?,?)";
	public static String adminSearchSQL = "select * from Admin where vendor_Id=? and password=?";
	public static String updatePasswordSQL = "update user set password=? where user_Id=? ";
	public static String searchPolicySQL = "select* from policydetails where user_Id=?";
	public static String searchSQL = "select * from user where user_Id=?";
	public static String adminLoginSQL = "select Vendor_Id,password from Admin where vendor_Id=? and password=?";
	public static String userLoginSQL = "select User_Id,password from user where User_Id=? and password=?";
	public static String vehicleDetailsSQL = "insert into vehicle values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
	public static String driverDetailsSQL = "insert into driver values(?,?,?,?,?,?,?)";
	public static String insertCoveragesSQL = "insert into coverages values(?,?,?,?,?,?,?,?,default)";
	public static String policyHolderSql= "insert into policyHolderDetails values(?,?,?,?,?,?,?,?,?)";
	public static String searchVEHICLESQL = "select * from policy where user_Id=?";
	public static String policyDetailsSQL = "insert into policydetails values(?,?,?,?,?,?,?,?,?,?)";
	public static String UderWriterRegisrtationSQL = "insert into UnderWriterDetails values(?,?,?,?)";
	public static String underWriteLoginSQL = "select under_Writer_id,Under_Writer_password from underWriterdetails where Under_Writer_id=? and under_writer_password=?";
	public static String sendingApllicationSQL = "select under_Writer_id,Under_Writer_password from underWriterdetails where Under_Writer_id=? and under_writer_password=?";
	public static String SQl="select distinct policyholderdetails.*,driver.*,vehicle.*,coverages.* from policyholderdetails  inner join driver on policyholderdetails.user_id=driver.user_id inner join vehicle on policyholderdetails.user_id=vehicle.user_id inner join coverages on policyholderdetails.user_id=coverages.user_id   where driver.user_id=?";
	public static String pendingUserIds= "select user_id from coverages where status ='pending'";
	public static String updateSQL = "update Coverages set status=? where user_id=?";

}
