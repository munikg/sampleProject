package com.sims.policymanagementsystem.action;

import java.util.Scanner;

import com.sims.policymanagementsystem.dao.InsuranceDAO;
import com.sims.policymanagementsystem.vo.VehicleVO;

public class AddVehicleDetails {
	VehicleVO vvo = new VehicleVO();
	InsuranceDAO idao = new InsuranceDAO();

	public void vehicleDetails() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter UserID :");
		int id = sc.nextInt();
		vvo.setUserID(id);
		System.out.println("Enter Registration Number :");
		String rnum = sc.next();
		vvo.setRegistrationNumber(rnum);
		System.out.println("Enter Vehicle Age :");
		int vAge = sc.nextInt();
		if (vAge > 4) {
			System.out.println("Your Vehicle Is  Not Eligile for Policy");
		} else {
			vvo.setVehicleAge(vAge);
			System.out.println("Enter Month And Year Of registration in the form of MM/YYYY :");
			String month = sc.next();
			vvo.setYearOfRegistration(month);
			System.out.println("Enter vehicle Model:");
			String vm = sc.next();
			vvo.setVehicleModel(vm);
			System.out.println("Enter vehicle Name :");
			String vn = sc.next();
			vvo.setVehicleName(vn);
			System.out.println("Enter Fuel Type:");
			String ft = sc.next();
			vvo.setFuelType(ft);
			System.out.println("Enter year Of manufacture YYYY:");
			int ym = sc.nextInt();
			vvo.setYearOfManufacture(ym);
		}
		System.out.println("Enter vehicle Cost:");
		int cost = sc.nextInt();

		vvo.setVehicleCost(cost);
		System.out.println("Enter seating capacity :");
		int c = sc.nextInt();
		vvo.setSeatingCapacity(c);
		System.out.println(" Enter Vehicle IDV");
		int idv = sc.nextInt();
		vvo.setVehicleIDV(idv);
		System.out.println("Enter Chassis No:");
		String cn = sc.next();
		vvo.setChassisNo(cn);
		System.out.println("Enter Engine cc :");
		int ecc = sc.nextInt();
		if (ecc > 1000) {
			System.out.println("Your Premium Will be Low");
		} else {
			System.out.println("your premium is will be high");
		}
		vvo.setEngineCC(ecc);
		idao.addDetailsOfVehicle(vvo);
		System.out.println("Do You want add another Vehicle Enter Y/N :");
		String choice = sc.next();
		if (choice.equalsIgnoreCase("y")) {

			this.vehicleDetails();

		} else if (choice.equalsIgnoreCase("n")) {
			System.out.println("Thank You For Adding vehicle Details");
		} else {
			System.out.println("Select  Valid Option");
		}

	}

	public static void main(String[] args) {
		AddVehicleDetails ad = new AddVehicleDetails();
		ad.vehicleDetails();
	}

}
