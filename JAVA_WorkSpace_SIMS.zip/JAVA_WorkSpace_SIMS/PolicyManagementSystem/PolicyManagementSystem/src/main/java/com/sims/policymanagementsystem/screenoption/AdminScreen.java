package com.sims.policymanagementsystem.screenoption;

import java.util.Scanner;

import com.sims.policymanagementsystem.action.PolicyAction;
import com.sims.policymanagementsystem.action.SearchPolicy;

public class AdminScreen {
	public void adminScreen() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Welome to Insurance Management System");
		System.out.println("1.PolicyDetails" + '\n' + "2.search policy" + '\n' + "3.exit");
		System.out.println("Please Enter Option Number :");

		int option = sc.nextInt();

		switch (option) {
		case 1:
			PolicyAction pa = new PolicyAction();
			pa.policyDetails();
			break;
		case 2:
			SearchPolicy sp = new SearchPolicy();
			sp.search();
			break;
		case 3:
			System.out.println("Your Exited Successfully");
			break;

		default:
			System.out.println("Enter Valid Option");
		}
		System.out.println("Do You Want To Continue Enter Y/N :");
		String choice = sc.next();
		if (choice.equalsIgnoreCase("y")) {

			this.adminScreen();

		} else if (choice.equalsIgnoreCase("n")) {
			System.out.println("Thank You For Visiting ");
		} else {
			System.out.println("Select  Valid Option");
		}

	}

}
