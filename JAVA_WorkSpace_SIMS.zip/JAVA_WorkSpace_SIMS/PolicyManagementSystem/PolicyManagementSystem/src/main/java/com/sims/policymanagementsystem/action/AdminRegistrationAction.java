package com.sims.policymanagementsystem.action;

import java.util.Scanner;

import com.sims.policymanagementsystem.dao.InsuranceDAO;
import com.sims.policymanagementsystem.vo.AdminVO;

public class AdminRegistrationAction {
	AdminVO avo = new AdminVO();

	public void adminRegistration() {
		InsuranceDAO idao = new InsuranceDAO();
		Scanner sc = new Scanner(System.in);

		System.out.println("Register And Continue......");
		System.out.println("Enter First Name : ");
		avo.setFirstName(sc.next());
		System.out.println("Enter Last Name :");
		avo.setLastname(sc.next());
		System.out.println("Enter Age :");
		avo.setAge(sc.nextInt());
		System.out.println("Enter Gender :");
		avo.setGender(sc.next());
		System.out.println("Enter Contact Number :");
		avo.setContactNumber(sc.next());
		System.out.println("Set Vendor Id :");
		avo.setVendorID(sc.nextInt());
		System.out.println("Set password :");
		avo.setPassword(sc.next());

		idao.adminRegistration(avo);
		
	}

	

}
