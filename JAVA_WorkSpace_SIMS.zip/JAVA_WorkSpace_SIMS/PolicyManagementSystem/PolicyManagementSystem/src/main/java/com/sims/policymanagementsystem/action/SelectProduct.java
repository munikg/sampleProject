package com.sims.policymanagementsystem.action;

import java.util.Scanner;

public class SelectProduct{
	public void typesOfPolicies() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Products Available");
		System.out.println("1.AUTO POLICY");
        System.out.println("Select Product By its Number To Continue");
        int option=sc.nextInt();
        switch (option) {
		case 1:
			System.out.println("Add Policy Holder Details :");
			PolicyHolderAction pha=new PolicyHolderAction();
			pha.policyHolder();
			System.out.println("Add Your Vehicle Details :");
			AddVehicleDetails avd=new AddVehicleDetails();
			avd.vehicleDetails();
			System.out.println("Add Driver Detailes");
			DriverDetailsAction dda=new DriverDetailsAction();
			dda.driverDetails();
			System.out.println("Select Coverages You Want");
			SelectCoveragesActions sca=new SelectCoveragesActions();
			sca.coverages();
			
			break;

		default:
			System.out.println("You are Entering Invalid Option Numbers");
			break;
		}
	}

	

}
