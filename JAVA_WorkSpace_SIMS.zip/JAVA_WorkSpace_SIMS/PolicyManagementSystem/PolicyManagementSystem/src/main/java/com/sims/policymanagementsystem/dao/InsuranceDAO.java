package com.sims.policymanagementsystem.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import com.sims.policymanagementsystem.action.PendingApplication;
import com.sims.policymanagementsystem.action.SelectProduct;
import com.sims.policymanagementsystem.action.UnderWriterReviewedIDs;
import com.sims.policymanagementsystem.cc.CC;
import com.sims.policymanagementsystem.screenoption.AdminScreen;
import com.sims.policymanagementsystem.screenoption.UserScreenOptions;
import com.sims.policymanagementsystem.vo.AdminVO;
import com.sims.policymanagementsystem.vo.CoveragesVO;
import com.sims.policymanagementsystem.vo.DriverVO;
import com.sims.policymanagementsystem.vo.PolicyHolderVO;
import com.sims.policymanagementsystem.vo.PolicyVO;
import com.sims.policymanagementsystem.vo.UnderWriterVO;
import com.sims.policymanagementsystem.vo.UserVO;
import com.sims.policymanagementsystem.vo.VehicleVO;

public class InsuranceDAO {
	public boolean checkForExistence(int userID, String password) {
		boolean flag = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/insurance?autoReconnect=true&useSSL=false", "root", "root");
		
			PreparedStatement pstmt = con.prepareStatement(CC.usersearchSQL);
			pstmt.setInt(1, userID);
			pstmt.setString(2, password);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public void userRegistration(UserVO uvo) {
		boolean result = checkForExistence(uvo.getUserID(), uvo.getPassword());
		if (result) {
			System.out.println(" Invalid..Please Try Differenet User ID and Password");
		} else {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection(
						"jdbc:mysql://localhost:3306/insurance?autoReconnect=true&useSSL=false", "root", "root");

				PreparedStatement stmt = con.prepareStatement(CC.userRegisrtationSQL);
				stmt.setString(1, uvo.getFirstName());
				stmt.setString(2, uvo.getLastname());
				stmt.setInt(3, uvo.getAge());
				stmt.setString(4, uvo.getGender());
				stmt.setString(5, uvo.getContactNumber());
				stmt.setInt(6, uvo.getUserID());
				stmt.setString(7, uvo.getPassword());
				int i = stmt.executeUpdate();
				if (i > 0) {
					System.out.println("Registration Suceesfull with UserID :"+uvo.getUserID());
					System.out.println("Welcome To Insurance Management System..");

					SelectProduct sp=new SelectProduct();
					sp.typesOfPolicies();
				}

			} catch (Exception e) {
				e.printStackTrace();
			}

		}

	}

	public boolean checkForExistence1(int vendorID, String password) {
		boolean flag = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/insurance", "root", "root");

			PreparedStatement pstmt = con.prepareStatement(CC.adminSearchSQL);
			pstmt.setInt(1, vendorID);
			pstmt.setString(2, password);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public void adminRegistration(AdminVO avo) {
		boolean res = checkForExistence1(avo.getVendorID(), avo.getPassword());
		if (res) {
			System.out.println("Invalid ..Please Try Agian with Different ID and Password");
		} else {

			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/insurance", "root", "root");
			
				PreparedStatement stmt = con.prepareStatement(CC.adminRegisrtationSQL);
				stmt.setString(1, avo.getFirstName());
				stmt.setString(2, avo.getLastname());
				stmt.setInt(3, avo.getAge());
				stmt.setString(4, avo.getGender());
				stmt.setString(5, avo.getContactNumber());
				stmt.setInt(6, avo.getVendorID());
				stmt.setString(7, avo.getPassword());
				int i = stmt.executeUpdate();
				if (i > 0) {
					System.out.println(" Admin Registration Suceesfull");
					System.out.println(" Close The Application and Restart Again");

				}

			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}

	public void setnewPassword(int userID, String password) {
		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/insurance?autoReconnect=true&useSSL=false", "root", "root");
			
			PreparedStatement stmt = con.prepareStatement(CC.searchSQL);
			stmt.setInt(1, userID);
			// stmt.setString(2, password);
			ResultSet rs = stmt.executeQuery();
			if (rs.next() == true) {
				PreparedStatement stmt1 = con.prepareStatement(CC.updatePasswordSQL);
				stmt1.setString(1, password);
				stmt1.setInt(2, userID);
				int i = stmt1.executeUpdate();
				if (i > 0) {
					System.out.println("Updated Password Successfully");
				}
			} else {
				System.out.println("Invalid UserID..Please Try Again");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

		public void adminLogin(int vendorID, String password) {
		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/insurance?autoReconnect=true&useSSL=false", "root", "root");
			System.out.println("Connected to Database Successfully");

			PreparedStatement stmt = con.prepareStatement(CC.adminLoginSQL);
			stmt.setInt(1, vendorID);
			stmt.setString(2, password);

			ResultSet rs = stmt.executeQuery();
			if (rs.next() == true) {
				System.out.println("login successfull");
				AdminScreen as = new AdminScreen();
				as.adminScreen();

			}

			else {
				System.out.println("Invalid Credentials..Please Try Again..");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void userLogin(int userID, String password) {
		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/insurance?autoReconnect=true&useSSL=false", "root", "root");
			

			PreparedStatement stmt = con.prepareStatement(CC.userLoginSQL);
			stmt.setInt(1, userID);
			stmt.setString(2, password);

			ResultSet rs = stmt.executeQuery();
			if (rs.next() == true) {
				System.out.println("login successfull");
				UserScreenOptions uso = new UserScreenOptions();
				uso.userScreen();
			}

			else {
				System.out.println("Invalid Credentials..Please Try Again..");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void addDetailsOfVehicle(VehicleVO vvo) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/insurance?autoReconnect=true&useSSL=false", "root", "root");
	
			PreparedStatement stmt = con.prepareStatement(CC.vehicleDetailsSQL);
			stmt.setInt(1, vvo.getUserID());
			stmt.setString(2, vvo.getRegistrationNumber());
			stmt.setInt(3, vvo.getVehicleAge());
			stmt.setString(4, vvo.getYearOfRegistration());
			stmt.setString(5, vvo.getVehicleModel());
			stmt.setString(6, vvo.getVehicleName());
			stmt.setString(7, vvo.getFuelType());
			stmt.setInt(8, vvo.getYearOfManufacture());
			stmt.setInt(9, vvo.getVehicleCost());
			stmt.setInt(10, vvo.getSeatingCapacity());
			stmt.setInt(11, vvo.getVehicleIDV());
			stmt.setString(12, vvo.getChassisNo());
			stmt.setInt(13, vvo.getEngineCC());

			int i = stmt.executeUpdate();
			if (i > 0) {
				System.out.println("Vehicle Details Added Suceesfully");
			} else {
				System.out.println("Something Went Wrong Please Check Once");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void addDetailsOfDriver(DriverVO dvo) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/insurance?autoReconnect=true&useSSL=false", "root", "root");
			
			PreparedStatement stmt = con.prepareStatement(CC.driverDetailsSQL);
			stmt.setInt(1, dvo.getUserId());
			stmt.setString(2, dvo.getDriverName());
			stmt.setString(3, dvo.getLicenseNO());
			stmt.setString(4, dvo.getLicenseIssueDate());
			stmt.setString(5, dvo.getLicenseExPiryDate());
			stmt.setInt(6, dvo.getDrivingExperience());
			stmt.setInt(7, dvo.getDriverAge());

			int i = stmt.executeUpdate();
			if (i > 0) {
				System.out.println("Driver Details Added Suceesfully");
			} else {
				System.out.println("Something Went Wrong Please Check Once");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void coveragesOpted(CoveragesVO cvo) {

		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/insurance?autoReconnect=true&useSSL=false", "root", "root");
			PreparedStatement stmt = con.prepareStatement(CC.searchSQL);
			stmt.setInt(1, cvo.getUserID());

			ResultSet rs = stmt.executeQuery();
			if (rs.next() == true) {
				PreparedStatement stmt1 = con.prepareStatement(CC.insertCoveragesSQL);
				stmt1.setInt(1, cvo.getUserID());
				stmt1.setString(2, cvo.getAutoLiabilityCoverage());
				stmt1.setString(3, cvo.getUninsuredAndUnderinsuredMotoristCoverage());
				stmt1.setString(4, cvo.getComprehensiveCoverage());
				stmt1.setString(5, cvo.getCollisionCoverage());
				stmt1.setString(6, cvo.getMedicalPaymentsCoverage());
				stmt1.setString(7, cvo.getPersonalInjuryProtection());
				stmt1.setInt(8, cvo.getPremium());
				int i = stmt1.executeUpdate();
				if (i > 0) {
					System.out.println("coverages selected Successfully");
				}
			}

			else {
				System.out.println("Invalid Credentials..Please Try Again to add coveages to Policy");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void policyHolderDetails(PolicyHolderVO pv) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/insurance?autoReconnect=true&useSSL=false", "root", "root");
			
			PreparedStatement stmt = con.prepareStatement(CC.policyHolderSql);
			stmt.setInt(1, pv.getUserID());
			stmt.setString(2, pv.getName());
			stmt.setString(3, pv.getAdress());
			stmt.setString(4, pv.getPhoneNumber());
			stmt.setString(5, pv.getResidentialNumber());
			stmt.setString(6, pv.getEmailId());
			stmt.setString(7, pv.getProfession());
			stmt.setString(8, pv.getProductName());
			stmt.setString(9, pv.getPeriodOfInsurance());
			int i = stmt.executeUpdate();
			if (i > 0) {
				System.out.println("Thank You For Adding Details.....");
				System.out.println("Your Policy Id :"+pv.getUserID());
			} else {
				System.out.println("Something Went Wrong Please Check Once");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void addPolicy(PolicyVO po) {
		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/insurance?autoReconnect=true&useSSL=false", "root", "root");
			
			PreparedStatement stmt = con.prepareStatement(CC.searchSQL);
			stmt.setInt(1, po.getUserID());

			ResultSet rs = stmt.executeQuery();
			if (rs.next() == true) {
				PreparedStatement stmt1 = con.prepareStatement(CC.policyDetailsSQL);
				stmt1.setString(1, po.getPolicyNumber());
				stmt1.setString(2, po.getPeriodOfInsurance());
				stmt1.setString(3, po.getInsuredName());
				stmt1.setString(4, po.getInsuredAddress());
				stmt1.setString(5, po.getProduct());
				stmt1.setString(6, po.getPolicyIssuedOn());
				stmt1.setFloat(7, po.getPremium());
				stmt1.setInt(8, po.getUserID());
				stmt1.setString(9, po.getPolicyStatus());
				stmt1.setString(10, po.getPolicyHolderState());

				int i = stmt1.executeUpdate();
				if (i > 0) {
					System.out.println("policy generated Successfully");
				}
			}

			else {
				System.out.println("Invalid userId Credentials..Please Try Again..");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void UnderWriteRecord(UnderWriterVO uvo) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/insurance?autoReconnect=true&useSSL=false", "root", "root");
		
			PreparedStatement stmt = con.prepareStatement(CC.UderWriterRegisrtationSQL);
			stmt.setString(1, uvo.getUnderWriterName());
			stmt.setInt(2, uvo.getUnderWriterID());
			stmt.setString(3, uvo.getUnderWriterPassword());
			stmt.setInt(4, uvo.getUnderWriterExperince());

			int i = stmt.executeUpdate();
			if (i > 0) {
				System.out.println("Registration Suceesfull");

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void underWriterLogin(int id, String password) {
		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/insurance?autoReconnect=true&useSSL=false", "root", "root");
		

			PreparedStatement stmt = con.prepareStatement(CC.underWriteLoginSQL);
			stmt.setInt(1, id);
			stmt.setString(2, password);

			ResultSet rs = stmt.executeQuery();
			if (rs.next() == true) {
				do{System.out.println("Quote IDs Pending");
				System.out.println("-------------------");
				UnderWriterReviewedIDs ur = new UnderWriterReviewedIDs();
				ur.pendingUserIDs();

				PendingApplication pa = new PendingApplication();
				pa.viewPendingApplication();
				System.out.println("Enter The Review :");
				pa.status();
				System.out.println("Remaining Policy Id's In Pending..");
				}while(true);

			}

			else {
				System.out.println("Invalid Credentials..Please Try Again..");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void getPendingApplication(int userID) {
		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/insurance?autoReconnect=true&useSSL=false", "root", "root");
			
			PreparedStatement stmt = con.prepareStatement(CC.searchSQL);
			stmt.setInt(1, userID);
			ResultSet rs = stmt.executeQuery();
			if (rs.next() == true) {
				PreparedStatement stmt1 = con.prepareStatement(CC.SQl);
				stmt1.setInt(1, userID);
				ResultSet rs1 = stmt1.executeQuery();
				if(rs1.next()==false) {
					System.out.println("No Policy For This ID..Please Go Back And Register Policy...");
				}
				else {
				do{
					System.out.println("--------------------------------------------------------------");
					System.out.println("Insured Details ");
					System.out.println("--------------------------------------------------------------");
					System.out.println("InsuredID          :" + rs1.getInt(1));
					System.out.println("Name               :" + rs1.getString(2));
					System.out.println("Adress             :" + rs1.getString(3));
					System.out.println("Phone Number       :" + rs1.getString(4));
					System.out.println("Resenditial Number :" + rs1.getString(5));
					System.out.println("EmailID            :" + rs1.getString(6));
					System.out.println("Profession         :" + rs1.getString(7));
					System.out.println("Product            :" + rs1.getString(8));
					System.out.println("period Of insurance:" + rs1.getString(9));
					System.out.println("--------------------------------------------------------------");
					System.out.println("Driver Details :");
					System.out.println("--------------------------------------------------------------");
					System.out.println("Driver Name        :" + rs1.getString(11));
					System.out.println("License Number     :" + rs1.getString(12));
					System.out.println("License Expiry Date:" + rs1.getString(14));
					System.out.println("Driving Experience :" + rs1.getString(15));
					System.out.println("Driver Age         :" + rs1.getString(16));
					System.out.println("---------------------------------------------------------------");
					System.out.println("VEHICLE DETAILS:");
					System.out.println("----------------------------------------------------------------");
					System.out.println("Registration Number          :" + rs1.getString(18));
					System.out.println("Vehicle Age                  :" + rs1.getInt(19));
					System.out.println("Month And Year Of registraion:" + rs1.getString(20));
					System.out.println("Vehicle Model                :" + rs1.getString(21));
					System.out.println("Vehicle Name                 :" + rs1.getString(22));
					System.out.println("Fuel Type                    :" + rs1.getString(23));
					System.out.println("Year Of Manufacture          :" + rs1.getString(24));
					System.out.println("Vehicle cost                 :" + rs1.getString(25));
					System.out.println("Vehicle Identification number:" + rs1.getString(28));
					System.out.println("Engine cc                    :" + rs1.getString(29));
					System.out.println("-------------------------------------------------------------------");
					System.out.println("COVERAGES Details :");
					System.out.println("-------------------------------------------------------------------");
					System.out.println("Auto Liability Coverage                    :" + rs1.getString(31));
					System.out.println("Under Insured &UnInsured Motarist Coverage :" + rs1.getString(32));
					System.out.println("Comprehensive Coverage                     :" + rs1.getString(33));
					System.out.println("Collision coverage                         :" + rs1.getString(34));
					System.out.println("Medical Payments                           :" + rs1.getString(35));
					System.out.println("Bodily Injured Coverage                    :" + rs1.getString(36));
					System.out.println("Premium                                    :" + rs1.getInt(37));
					System.out.println("Status Of The Quote                        :" + rs1.getString(38));
					System.out.println("--------------------------------------------------------------------");
				}while(rs1.next());
				}
				
			} else {
				System.out.println("Invalid UserID..Please Try Again to Fetch Details");
			}con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}

	public void pendingApplicationUserIDs() {

		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/insurance?autoReconnect=true&useSSL=false", "root", "root");

			PreparedStatement stmt = con.prepareStatement(CC.pendingUserIds);

			ResultSet rs = stmt.executeQuery();
			
			if (rs.next()==false) {
				System.out.println("No Quote Id's For Today Enjoy..");
				
			} else {
				do {
					System.out.println(rs.getInt(1));
				} while (rs.next()) ;
			}

			

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void status(int quoteId, String status) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/insurance?autoReconnect=true&useSSL=false", "root", "root");
			PreparedStatement stmt = con.prepareStatement(CC.searchSQL);
			stmt.setInt(1, quoteId);
            ResultSet rs=stmt.executeQuery();
			if(rs.next()==true) {
			PreparedStatement stmt1 = con.prepareStatement(CC.updateSQL);
            
			stmt1.setString(1, status);
			stmt1.setInt(2, quoteId);
			int i = stmt1.executeUpdate();

			if (i > 0) {
				System.out.println("Reviewd succesfully with Id:" + quoteId);
			}
			}else {
				System.out.println("Invalid User ID..");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		}

	}


