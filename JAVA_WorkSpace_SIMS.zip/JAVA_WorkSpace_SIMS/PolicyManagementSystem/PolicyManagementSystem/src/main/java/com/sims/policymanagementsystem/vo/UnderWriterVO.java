package com.sims.policymanagementsystem.vo;

public class UnderWriterVO {
    String UnderWriterName;
    int UnderWriterID;
    String UnderWriterPassword;
    int UnderWriterExperince;
	public String getUnderWriterName() {
		return UnderWriterName;
	}
	public void setUnderWriterName(String underWriterName) {
		UnderWriterName = underWriterName;
	}
	public int getUnderWriterID() {
		return UnderWriterID;
	}
	public void setUnderWriterID(int underWriterID) {
		UnderWriterID = underWriterID;
	}
	public String getUnderWriterPassword() {
		return UnderWriterPassword;
	}
	public void setUnderWriterPassword(String underWriterPassword) {
		UnderWriterPassword = underWriterPassword;
	}
	public int getUnderWriterExperince() {
		return UnderWriterExperince;
	}
	public void setUnderWriterExperince(int underWriterExperince) {
		UnderWriterExperince = underWriterExperince;
	}
    
}
