package com.sims.policymanagementsystem.action;

import java.util.Scanner;

import com.sims.policymanagementsystem.dao.InsuranceDAO;

public class SearchPolicy {
	InsuranceDAO idao=new InsuranceDAO();
   public void search() {
	   Scanner sc=new Scanner(System.in);
	   System.out.println("Enter UserID To Search");
	   int id=sc.nextInt();
	  //idao.searchPolicy(id);
   }
   public static void main(String[] args) {
	SearchPolicy sp=new SearchPolicy();
	sp.search();
}
   
}
