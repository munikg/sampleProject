package com.sims.policymanagementsystem.action;

import java.util.Scanner;

import com.sims.policymanagementsystem.dao.InsuranceDAO;

public class PendingApplication {
	Scanner sc = new Scanner(System.in);
	InsuranceDAO idao = new InsuranceDAO();

	public void viewPendingApplication() {
		System.out.println("-----------------------------------");
		System.out.println("Enter Policy ID TO View Application");
		int userID = sc.nextInt();
		idao.getPendingApplication(userID);
	}
	public void status() {
	  System.out.println("Enter Policy ID");
	  int quoteId=sc.nextInt();
	  System.out.println("Enter Status Of The Application ");
	   String status=sc.next();
	   idao.status(quoteId,status);
	}

	public static void main(String[] args) {
		PendingApplication pa = new PendingApplication();
		pa.viewPendingApplication();
	}
}
