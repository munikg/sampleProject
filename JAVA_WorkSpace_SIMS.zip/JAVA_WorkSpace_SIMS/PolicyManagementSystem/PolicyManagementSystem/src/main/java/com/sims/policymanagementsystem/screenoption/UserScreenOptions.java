package com.sims.policymanagementsystem.screenoption;

import java.util.Scanner;

import com.sims.policymanagementsystem.action.PendingApplication;
import com.sims.policymanagementsystem.action.SelectProduct;

public class UserScreenOptions {
	public void userScreen() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Welome to Insurance Management System ");
		System.out.println("1.Select Product");
		System.out.println("2.Policy Details");
		System.out.println("3.Exit");
		System.out.println("Please Enter Option Number :");

		int option = sc.nextInt();

		switch (option) {
		case 1:
			SelectProduct sp = new SelectProduct();
			sp.typesOfPolicies();
			break;
		case 2:
			PendingApplication pa = new PendingApplication();
			pa.viewPendingApplication();
			break;
		case 3:
			System.out.println("You are Exited Successfully");
			break;
		default:
			System.out.println("Enter Valid Option");
		}
		System.out.println("Do You Want To continue Enter Y/N :");
		String choice = sc.next();
		if (choice.equalsIgnoreCase("y")) {

			this.userScreen();

		} else if (choice.equalsIgnoreCase("n")) {
			System.out.println("Thank You For Visiting ");
		} else {
			System.out.println("Select  Valid Option");
		}

	}

}
