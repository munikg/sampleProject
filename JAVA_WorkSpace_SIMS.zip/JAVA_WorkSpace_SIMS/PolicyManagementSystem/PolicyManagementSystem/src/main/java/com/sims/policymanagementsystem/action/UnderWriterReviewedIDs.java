package com.sims.policymanagementsystem.action;

import com.sims.policymanagementsystem.dao.InsuranceDAO;

public class UnderWriterReviewedIDs {
	InsuranceDAO idao=new InsuranceDAO();
	public void pendingUserIDs() {
		idao.pendingApplicationUserIDs();
	}
	public static void main(String[] args) {
		UnderWriterReviewedIDs rw=new UnderWriterReviewedIDs();
		rw.pendingUserIDs();
	}

}
