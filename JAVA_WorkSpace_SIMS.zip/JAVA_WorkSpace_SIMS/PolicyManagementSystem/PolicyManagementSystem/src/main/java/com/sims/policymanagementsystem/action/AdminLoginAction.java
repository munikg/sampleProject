package com.sims.policymanagementsystem.action;

import java.util.Scanner;

import com.sims.policymanagementsystem.dao.InsuranceDAO;

public class AdminLoginAction {
	 public void admin() {
		InsuranceDAO idao=new InsuranceDAO();
		Scanner sc=new  Scanner(System.in);
		System.out.println("Enter Vendor_ID :");
		int vendorID=sc.nextInt();
		System.out.println("Enter Password  :");
		String password=sc.next();
		idao.adminLogin(vendorID,password);
		
	}

}
