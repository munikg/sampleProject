package com.sims.policymanagementsystem.action;

import java.util.Scanner;

import com.sims.policymanagementsystem.dao.InsuranceDAO;
import com.sims.policymanagementsystem.vo.UnderWriterVO;

public class UnderWriterAction {
	UnderWriterVO uvo=new UnderWriterVO();
	InsuranceDAO idao=new InsuranceDAO();
	public void underWriterReg() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter UnderWriter Name :");
		uvo.setUnderWriterName(sc.next());
		System.out.println("Set UnderWriter ID :");
		uvo.setUnderWriterID(sc.nextInt());
		System.out.println("Set Password ");
		uvo.setUnderWriterPassword(sc.next());
		System.out.println("Enter Your Experince");
		uvo.setUnderWriterExperince(sc.nextInt());
		idao.UnderWriteRecord(uvo);
	}
	public static void main(String[] args) {
		UnderWriterAction ua=new UnderWriterAction();
		ua.underWriterReg();
	}

}
