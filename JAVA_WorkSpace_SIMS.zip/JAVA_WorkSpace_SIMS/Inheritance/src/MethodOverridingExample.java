
public class MethodOverridingExample {
    void fatherMethod() {
    	
    	System.out.println("Father give a house to his child..");
    }
    public  static void  hello() {
   	 System.out.println("muni");
    }
}
