
public class A {

 void sum(int j,int k) {
	System.out.println("sum is :"+j+k);
	
}
 private void hi() {
	 System.out.println("Hi....");
 }
 
}
