
public class Son extends MethodOverridingExample {
   void fatherMethod() {
	   super.fatherMethod();
	   System.out.println("son destroy fathers house and build his new house");
	   
   }
   public  static void  hello() {
	
		 System.out.println("munikiran");
	 }
   public static void main(String[] args) {
	Son s=new Son();
	s.fatherMethod();
	s.hello();
}
}
