
public class Bike extends Engine {
	   void bName() {
		   System.out.println("pulsar");
	   }
	   void color() {
		   System.out.println("red");
	   }

}
