
public class Tength {
  void TengthMarks() {
	  System.out.println(" tength CGPA is: 5.5");
  }
}
