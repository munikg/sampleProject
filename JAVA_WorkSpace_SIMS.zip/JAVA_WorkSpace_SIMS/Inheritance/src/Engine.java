
public class Engine {
    
     void combustion() {
    	 System.out.println("bike Started after Combustion");
     }
     void engineModel(){
    	 System.out.println("bs6 engine");
     }
}
