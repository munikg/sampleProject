
public class B extends A {
	

	void mul(int l,int m) {
		System.out.println("mul is:"+(l*m));
	}
	
   
}
