
public class Degree extends Inter {
	void degree() {
		System.out.println(" degree percentage is : 35.6");
	}

	public static void main(String[] args) {
		System.out.println("Student Marks :");
		Degree d = new Degree();
		d.TengthMarks();
		d.interMarks();
		d.degree();
	}
}
