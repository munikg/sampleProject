
public class C extends B {
	void sub(int i, int j) {

		System.out.println("sub is"+(i-j));
	}

	public static void main(String[] args) {
		C c = new C();

		c.sum(10, 20);
		c.mul(30, 20);
		c.sub(40, 20);

	}

}
