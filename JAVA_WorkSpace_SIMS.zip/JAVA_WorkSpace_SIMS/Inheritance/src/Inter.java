
public class Inter extends Tength {
 void interMarks() {
	 System.out.println(" inter Marks is : 999");
 }
}
