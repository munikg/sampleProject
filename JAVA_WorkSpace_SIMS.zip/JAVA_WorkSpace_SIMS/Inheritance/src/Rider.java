
public class Rider extends Bike {
	void riderName() {
		System.out.println("Kiran....");
	}
	void ride() {
		System.out.println("ride to goa...");
	}
	
	public static void main(String[] args) {
		Rider r=new Rider();
		r.riderName();
		r.bName();
		r.engineModel();
		r.combustion();
		r.color();
		r.ride();
			
	}

}
