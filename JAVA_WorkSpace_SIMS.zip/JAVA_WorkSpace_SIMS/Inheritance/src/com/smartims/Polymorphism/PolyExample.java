package com.smartims.Polymorphism;

public class PolyExample {
   void login(long phNo) {
	   System.out.println("login success full with number ");
   }
   void login( String uName,String psw) {
	   uName="SIMS";
	   System.out.println("welome to Insta.."+uName);
   }
   public static void main(String[] args) {
	PolyExample p=new PolyExample();
	  p.login(9876453292l);
	  p.login("kiran", "as123qw");
}
}
