package com.smartims.Polymorphism;

public class DButilCon {
	void conDB(String url, String uName, String psw, int portNo) {
		System.out.println("Oracle DB connection succeessfull");
	}

	void conDB(String url, String uName, String psw) {
		System.out.println("Mysql DB connection succeessfull");
	}

	void conDB(String url, String uName) {
		System.out.println("sybase DB connection succeessfull");
	}

	public static void main(String[] args) {
		DButilCon db = new DButilCon();
		db.conDB("cn.db", "kiran","123qweasd",8080);
		db.conDB("cn.db", "kiran","123qweasd");
		db.conDB("cn.db", "kiran");
	}
}
