package com.smartims.vo;

public class UnderWriterVO {
	int uw_id;
	String uw_name;
	String uw_email;
	String password;

	public int getUw_id() {
		return uw_id;
	}

	public void setUw_id(int uw_id) {
		this.uw_id = uw_id;
	}

	public String getUw_name() {
		return uw_name;
	}

	public void setUw_name(String uw_name) {
		this.uw_name = uw_name;
	}

	public String getUw_email() {
		return uw_email;
	}

	public void setUw_email(String uw_email) {
		this.uw_email = uw_email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
