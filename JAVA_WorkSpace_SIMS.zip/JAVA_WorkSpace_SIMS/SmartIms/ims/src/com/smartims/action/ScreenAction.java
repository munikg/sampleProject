package com.smartims.action;

import java.util.Scanner;

public class ScreenAction {
	Scanner ip = new Scanner(System.in);

	void screenValues() {
		System.out.println("Welcome To Insurance");
		System.out.println("Please select below options to Login :");
		System.out.println("1.Agent Login -- 2.Underwriter Login -- 3.Customer Login -- 4.Customer Register");
		int opt = ip.nextInt();
		switch (opt) {
		case 1:
			System.out.println("Agent Login :");
			LoginAgent la = new LoginAgent();
			la.loginAgent();
			break;
		case 2:
			System.out.println("UnderWriter Login :");
			LoginUnderWriter lu = new LoginUnderWriter();
			lu.loginUnderWriter();
			break;
		case 3:
			System.out.println("Customer Login :");
			LoginCustomer lc = new LoginCustomer();
			lc.login();
			break;
		case 4:
			System.out.println("Register Customer :");
			RegisterCustomerAction rca = new RegisterCustomerAction();
			rca.registerCustomer();
			break;
		default:
			System.out.println("Invalid Option...");
		}
	}

	public static void main(String[] args) {
		ScreenAction sa = new ScreenAction();
		sa.screenValues();
	}
}
