package com.smartims.action;

import java.util.Scanner;

import com.smartims.dao.AgentDAO;

public class LoginAgent {
	Scanner ip = new Scanner(System.in);

	void loginAgent() {
		System.out.println("Welcome Agent !!");
		System.out.println("Enter  ID :");
		int agent_id = ip.nextInt();
		System.out.println("Enter Password :");
		String password = ip.next();

		AgentDAO adao = new AgentDAO();
		adao.login(agent_id, password);
	}

	public static void main(String[] args) {
		LoginAgent la = new LoginAgent();
		la.loginAgent();
	}
}
