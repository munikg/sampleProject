package com.smartims.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.mysql.jdbc.Statement;
import com.smartims.cc.CC;
import com.smartims.vo.CustomerVO;

public class CustomerDAO {

	public void insertCustomer(CustomerVO cvo) {

		try {
			Class.forName("com.mysql.jdbc.Driver");

			Connection con = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/ims?autoReconnect=true&useSSL=false", "root", "root");

			PreparedStatement ps = con.prepareStatement(CC.insertCustomer,Statement.RETURN_GENERATED_KEYS);

			ps.setString(1, cvo.getCus_name());
			ps.setString(2, cvo.getCus_email());
			ps.setLong(3, cvo.getCus_phone());
			ps.setString(4, cvo.getPassword());
			int result = ps.executeUpdate();
			ResultSet rs=ps.getGeneratedKeys();
	    	if (rs.next()) {

					System.out.println("Generated successfully with ID :" + rs.getInt(1));

				}
			
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void login(int cus_id, String password) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/ims?autoReconnect=true&useSSL=false", "root", "root");
			PreparedStatement ps = con.prepareStatement(CC.displayCustomer);
			ps.setInt(1, cus_id);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				System.out.println("Successfully Logged In ....");
			} else
				System.out.println("No Customer with ID :" + cus_id);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
