package com.smartims.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.smartims.cc.CC;
import com.smartims.vo.AgentVO;

public class AgentDAO {

	public void insertAgent(AgentVO avo) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ims?autoReconnect=true&useSSL=false", "root", "root");
			PreparedStatement ps = con.prepareStatement(CC.insertAgent);
			ps.setString(1, avo.getAgent_name());
			ps.setString(2, avo.getAgent_email());
			ps.setString(3, avo.getPassword());
			int result = ps.executeUpdate();
			if (result > 0)
				System.out.println("Registered Agent Details succesfully with ID:" + avo.getAgent_id());
			else
				System.out.println("Unable to register with ID:" + avo.getAgent_id());
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void login(int agent_id, String password) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ims?autoReconnect=true&useSSL=false", "root", "root");
			PreparedStatement ps = con.prepareStatement(CC.displayAgent);
			ps.setInt(1, agent_id);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				System.out.println("Successfully Logged In ....");
			}
			else
				System.out.println("No Agent with ID :"+agent_id);
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
