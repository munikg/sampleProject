package com.smartims.dao;

public class VehicleDAO {

	public void bike() {
		
		
	}

}
