import java.util.Scanner;

public class ConsecutiveNumbersSwap {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter The Consecutive Number");
		int num=sc.nextInt();
		int rev=0;
		while(num>0) {
			int temp=num%10;
			rev=temp;
			System.out.print(rev);
			num=num/10;
			
					
		}
		

	}

}
