import java.util.Arrays;
import java.util.Scanner;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter The Size Of Array:");
		int size=sc.nextInt();
		int arr[]=new int[size];
		for(int i=0;i<size;i++) {
			System.out.println("Enter The "+i+" Element");
			int element=sc.nextInt();
			arr[i]=element;
					
		}
		System.out.println(Arrays.toString(arr));
				

	}

}
