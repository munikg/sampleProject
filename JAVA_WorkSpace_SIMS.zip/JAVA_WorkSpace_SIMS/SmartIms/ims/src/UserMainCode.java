import java.util.Scanner;

public class UserMainCode {

	public int stocks(int input1, int[] input2) {

		int i;

		int max = input2[0];

		for (i = 1; i < input2.length; i++)
			if (input2[i] > max)
				max = input2[i];

		return max;

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		UserMainCode uc = new UserMainCode();
		System.out.println("Enter Input 1");
		int size = sc.nextInt();
		System.out.println("Enter Input 2");
		int[] size2 = new int[size];
		for(int i=0;i<=size-1;i++) {
			size2[i]=sc.nextInt();
		}
		
		System.out.println("Best price For Buying Stock");

		System.out.println(uc.stocks(size, size2));

	}
	
}
