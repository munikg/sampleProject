
public abstract class X {
void m1() {
	System.out.println("m1 method from X");
}
abstract void m2();
}
