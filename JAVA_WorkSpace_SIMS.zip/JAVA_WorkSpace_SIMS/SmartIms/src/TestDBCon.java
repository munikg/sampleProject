import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import com.sims.action.ActorVo;

class TestDBCon {
//	String dbURL = "jdbc:mysql://localhost:3306/training";
//	String username = "root";
//	String password = "root";

	void connectToDB() {
		ArrayList actorNamesList = new ArrayList();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila", "root", "root");
			// here sakila is database name, root is username and password
			System.out.println("Connected to Database Successfully");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select first_name,actor_id,last_update from actor ");

			while (rs.next()) {
				ActorVo avo = new ActorVo();
				avo.setFirst_name(rs.getString(1));
				avo.setActor_id(rs.getInt(2));
				avo.setLast_Update(rs.getTimestamp(3));
				actorNamesList.add(avo);
			}
			Iterator itr = actorNamesList.iterator();
			while (itr.hasNext()) {
				ActorVo avo1 = (ActorVo) itr.next();
				System.out.println(avo1.getActor_id() + "  " + avo1.getFirst_name()+"  "+avo1.getLast_Update());
			}

		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	public static void main(String[] args) {
		TestDBCon db = new TestDBCon();
		db.connectToDB();
	}
}