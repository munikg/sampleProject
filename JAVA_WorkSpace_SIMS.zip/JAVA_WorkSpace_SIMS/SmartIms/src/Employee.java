import com.smartims.constructors.DButil;

public class Employee {
	EncapsulationEx2 ee = new EncapsulationEx2();
	DButil db=new DButil();
	public void display(){
		String res=db.connDB("oracle");
		if(res.equalsIgnoreCase("success")) {
		System.out.println("inserted into table...Wait");
		ee.seteName("kiran");
		ee.setEmpId(234566);
		ee.setRole("Trainee");
		ee.setSalary(300000.00);
		ee.setPhNo(9087654321l);

		System.out.println("Employee Name : " + ee.geteName());
		System.out.println("Employee ID :" + ee.getEmpId());
		System.out.println("Role : " + ee.getRole());
		System.out.println("Salary :" + ee.getSalary());
		System.out.println("insertion completed..");
		}
		else {
			System.out.println("oops!..database connection failed!!");
		}
	}
	public static void main(String[] args) {
		Employee e=new Employee();
		e.display();
	}
}
