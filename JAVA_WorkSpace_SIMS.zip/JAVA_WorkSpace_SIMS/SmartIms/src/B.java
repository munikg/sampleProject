
public class B extends A {

	@Override
	void m2() {
		// TODO Auto-generated method stub
		System.out.println("m2 method");
		
	}
	void m3() {
		// TODO Auto-generated method stub
		System.out.println("m2 method");
		
	}
	

public static void main(String[] args) {
	   A a=new B();
	   a.m1();
	   a.m2();
	   //a.m3();
	
}
}
