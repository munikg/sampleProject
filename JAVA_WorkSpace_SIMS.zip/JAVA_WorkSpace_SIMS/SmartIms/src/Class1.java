
abstract public class Class1 {
abstract void printName();
void m1() {
	System.out.println("FF");
}
}
