
public class Table2 {
	Table t=new Table();
	Testing tt=new Testing();
	public  void result() {
		
		t.setNumber(2);
		tt.output(t);
		
	}
	public static void main(String[] args) {
		Table2 f=new Table2();
		f.result();
	}
    
}
