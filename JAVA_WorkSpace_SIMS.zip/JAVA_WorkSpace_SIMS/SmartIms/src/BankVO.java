
public abstract class BankVO {
	 abstract int rateOfInterest() ;
}
