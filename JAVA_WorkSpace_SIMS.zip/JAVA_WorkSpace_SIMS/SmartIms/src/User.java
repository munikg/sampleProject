import java.util.Scanner;
public class User {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the dish name :");
		String dish=sc.next();
		System.out.println("enter the Quantity :");
		int quantity=sc.nextInt();
		System.out.println("enter the cost :");
		int cost=sc.nextInt();

     KiranTiffins kt=new KiranTiffins(dish, quantity, cost);
	}

}
