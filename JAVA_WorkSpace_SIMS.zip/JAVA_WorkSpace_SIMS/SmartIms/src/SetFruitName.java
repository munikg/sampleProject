
public class SetFruitName {
	FruitsVO fvo=new FruitsVO();
	GetFruitNames gfn = new GetFruitNames();
	 void fruitDetails() {
		fvo.setName("orange"); 
		fvo.setCost(120);
		gfn.fruitNames(fvo);
	 }
	 public static void main(String[] args) {
		SetFruitName sfn=new SetFruitName();
		sfn.fruitDetails();
		
	}
	 

}
