
public class GetFruitNames {
	

	void fruitNames(FruitsVO fvo) {
		System.out.println("Fruit Name :"+fvo.getName());
		System.out.println("Cost :"+fvo.getCost());
	}

	

}
