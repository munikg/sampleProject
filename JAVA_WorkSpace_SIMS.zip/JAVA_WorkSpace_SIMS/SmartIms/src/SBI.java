import com.smartims.constructors.DButil;

public class SBI extends BankVO {
    DButil db=new DButil();
	@Override
	int rateOfInterest() {
		String res=db.connDB("Oracle");
		if(res.equalsIgnoreCase("success")) {
		// TODO Auto-generated method stub
		System.out.println(" SBI Database connected...");
		
		}
		else 
		{
			System.out.println("failed");
		}
		return 5;
	}
	public static void main(String[] args) {
		SBI sbi=new SBI();
		System.out.println("rateOfInterest : "+sbi.rateOfInterest());
		
	}

}
