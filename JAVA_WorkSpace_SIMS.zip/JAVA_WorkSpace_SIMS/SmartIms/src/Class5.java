
public class Class5 extends Class1 {

	void printName() {

		System.out.println("ganesh");
	}

	public static void main(String[] args) {
		Class2 c2 = new Class2();
		Class3 c3 = new Class3();
		Class4 c4 = new Class4();
		Class5 c5 = new Class5();
		c2.printName();
		c3.printName();
		c4.printName();
		c5.printName();
		
	}
}
