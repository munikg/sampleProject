
public class Testing {
	void output(Table t) {
		for(int i=1;i<=10;i++) {
			System.out.println(t.getNumber()*i);
		}
	}
	
}
