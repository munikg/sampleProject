
public class ConstructorEx1 extends ConstructorEx {

	static void method3() {
		System.out.println("1234234");

	}

	public static void main(String[] args) {
		ConstructorEx1 ce = new ConstructorEx1();
		ce.method2();

	}
}
