
public class Class3 extends Class1 {

	void printName() {
		// TODO Auto-generated method stub
		System.out.println("manoj");
	}

}
