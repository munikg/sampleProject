
public class ConstructorEx {
static int a=10;
     public ConstructorEx() {
    	 System.out.println("ghgshj");
     }
    static void  method2() {
    	 System.out.println("Munikiran");
     }
    void method1() {
    	System.out.println("dixcjhjdh");
    }
}
