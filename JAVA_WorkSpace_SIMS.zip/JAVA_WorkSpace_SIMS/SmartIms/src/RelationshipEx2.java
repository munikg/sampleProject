
public class RelationshipEx2 {
	static int a = 10;
	RelationshipEx re = new RelationshipEx();// has-a relationship

	static void m3() {
		RelationshipEx re = new RelationshipEx();
		re.m1();
		System.out.println(a);
	}

	public static void main(String[] args) {
		RelationshipEx2 re2 = new RelationshipEx2();
		// RelationshipEx re = new RelationshipEx();// uses a relationship

		re2.m3();
		re2.m3();
	}
}
