
public class Class4 extends Class1 {

	void printName() {
		// TODO Auto-generated method stub
		System.out.println("rajesh");
	}

}
