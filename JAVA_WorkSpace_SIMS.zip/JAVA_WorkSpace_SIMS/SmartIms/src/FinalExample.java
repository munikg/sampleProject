
public class FinalExample {
    int a=10;
    final int b=20;
    
    void printValues() {
    	//b=b+10;
    	a=a+10;
    	System.out.println(a);
    	System.out.println(b);
    }
    public static void main(String[] args) {
		FinalExample fe=new FinalExample();
		fe.printValues();
	}
}
