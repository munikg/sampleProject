
public class Y extends X {
	void m1() {
		super.m1();
		System.out.println("m1 method is overrided and printed..");
	}

	@Override
	void m2() {
		// TODO Auto-generated method stub
		System.out.println("m2 method implemented");
	}
	void m3() {
		System.out.println("m3 method");
	}

	public static void main(String[] args) {
		X x = new Y();
		x.m1();
		x.m2();
		//x.m3();
	}
}
