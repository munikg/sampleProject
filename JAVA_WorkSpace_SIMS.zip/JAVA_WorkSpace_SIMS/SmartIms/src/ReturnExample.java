
public class ReturnExample {
     int a=10;
     int b=20;
     //int c;
     int sum() {
        // c=a+b;
    	 return a+b;
     }
     int mul(){
    	 //int d=sum()*10;
    	 return sum()*10;
     }
     
    public static void main(String[] args) {
		ReturnExample re=new ReturnExample();
		System.out.println("Mul is :"+re.mul());
	}
    
}
