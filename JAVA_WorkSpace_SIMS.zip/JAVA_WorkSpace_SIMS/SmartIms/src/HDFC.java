import com.smartims.constructors.DButil;

public class HDFC extends BankVO {
	DButil db=new DButil();
	@Override
	int rateOfInterest() {
		// TODO Auto-generated method stub
		String res=db.connDB("Oracle");
		if(res.equalsIgnoreCase("success")) {
		// TODO Auto-generated method stub
		System.out.println("HDFC Database connected...");
		
		}
		else 
		{
			System.out.println("failed");
		}
		return 10;
	}
	public static void main(String[] args) {
		HDFC hdfc=new HDFC(); 
			System.out.println("rateOfInterest :"+hdfc.rateOfInterest());
		
	}

}
