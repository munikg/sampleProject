
public class ReturnThroughParameter {
	int sum(int i, int j) {
		return i + j;
	}

	int mul() {

		int k = sum(20, 33);
		//System.out.println(k * 10);
		return k*10;

	}
	int sub() {
		
		 return mul()-sum(10,20);  
	}

	public static void main(String[] args) {
		ReturnThroughParameter rp = new ReturnThroughParameter();
		System.out.println(rp.mul());
	}
}
