
public class ReturnType {
	int a = 10;
	int b = 20;

	void sum() {
		if (a == b) {
			System.out.println(a + b);
		} else {
			System.out.println(a == b);
		}
	}

	void mul() {
		if (a <= 10) {
			a = a + b;
			System.out.println(a * b);
		} else {
			System.out.println("Both are Not eqa");
		}

	}

	void sub() {

		if (a - b == 0) {
			System.out.println(a - b);
		} else {
			System.out.println("cool your operation does not match");
		}
       this.mul();
	}
	void disply() {
		this.sub();
	}
	public static void main(String[] args) {
		ReturnType obj=new ReturnType();
		obj.disply();
	}
}
