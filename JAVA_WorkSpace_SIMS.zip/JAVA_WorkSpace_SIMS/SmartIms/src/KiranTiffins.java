//import java.util.Scanner;
public class KiranTiffins {
	String dishName;
	int quantity;
	int cost;

	public KiranTiffins(String dishName, int quantity, int cost) {
		super();
		this.dishName = dishName;
		this.quantity = quantity;
		this.cost = cost;
		if (dishName.equalsIgnoreCase("dosa")) {
			bill();

		} else if (dishName.equalsIgnoreCase("idli")) {

			bill();
		} else {

			System.out.println("Receipe not available");
		}

	}

	public void bill() {
		System.out.println("quantity  :" + quantity + "  cost :" + quantity * cost + "  " + "dishName :" + dishName);

	}

}
