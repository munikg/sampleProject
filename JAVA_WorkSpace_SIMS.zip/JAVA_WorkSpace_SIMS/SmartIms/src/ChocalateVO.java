
public class ChocalateVO {
   String cName;
   int cCost;
public String getcName() {
	return cName;
}
public void setcName(String cName) {
	this.cName = cName;
}
public int getcCost() {
	return cCost;
}
public void setcCost(int cCost) {
	this.cCost = cCost;
}
   
}
