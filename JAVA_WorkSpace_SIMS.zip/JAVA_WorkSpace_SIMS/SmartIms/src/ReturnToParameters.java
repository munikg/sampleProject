
public class ReturnToParameters {
	int i=2;
	int j=2;
   void sum(int i,int j) {
	   int k=i+j;
	   System.out.println(k);
   }
   void sub() {
	  i=i-2;
	   int k=i-j;
	   System.out.println(k);
   }
   void mul() {
	   int k=i*j;
	   System.out.println(k);
   }
   public static void main(String[] args) {
	ReturnToParameters rtp=new  ReturnToParameters();
	rtp.sum(20, 20);
	rtp.sub();
	rtp.mul();
}
}
