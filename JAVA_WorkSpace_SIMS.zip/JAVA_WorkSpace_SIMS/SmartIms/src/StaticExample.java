
public class StaticExample {
    static int a=20;
    static int b=30;
    static int c;
    static void sum() {
    	c=a+b;
    	System.out.println("Sum is :"+c);
    }
    static void sub() {
    	c=a-b;
    	System.out.println("Substraction is :"+c);
    }
    static void mul() {
    	c=a*b;
    	System.out.println("Multiplication is :"+c);
    }
    static void printMyName() {
    	System.out.println("Kiran ....");
    }
    public static void main(String[] args) {
		StaticExample.printMyName();
		StaticExample.sum();
		StaticExample.sub();
		StaticExample.mul();
	}
}
