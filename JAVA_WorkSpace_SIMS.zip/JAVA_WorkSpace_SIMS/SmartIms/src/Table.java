
public class Table {
     int number;

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}
	
	
     public static void main(String[] args) {
    	 Table t=new Table();
 		t.setNumber(2);
 		System.out.println(t.getNumber());
	}
}
