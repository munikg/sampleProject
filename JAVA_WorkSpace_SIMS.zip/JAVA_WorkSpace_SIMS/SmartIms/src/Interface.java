
public interface Interface {
   public void getFloat(int x);
   boolean hi(String[] args);
   public  void main(String[] args) ;
   private void hello() {
}
   void m1();
}
