package com.sims.strings;

public class StringBufferExample {
	public void result() {
		StringBuffer sb = new StringBuffer("muni");

		System.out.println(sb.append("kiran"));//munikiran
		System.out.println(sb.insert(9, " learns java"));
		System.out.println(sb.delete(1,3));
		System.out.println(sb.reverse());
		System.out.println(sb.capacity());
	}

	public static void main(String[] args) {
		StringBufferExample sbe = new StringBufferExample();
		sbe.result();
	}
}
