package com.sims.strings;

public class Test {
     public void result() {
		String s1="kiran ";
		String s2="pavan";
		String s3=new String("kiran");
		//s1=s1.concat("g");//kiran g
		System.out.println(s1);
		char c=s1.charAt(4);//n
		System.out.println(c);
		System.out.println(s1.length());//6
		System.out.println(s1.contains("an"));//true
		System.out.println("muni"+s1.trim());//munikiran
		System.out.println(s1.isEmpty());//false
		System.out.println(s1.substring(1));//iran
		System.out.println(50+20+"hh"+(20+20));//70hh40
		System.out.println(s2.replace("p", "P"));//Pavan
		System.out.println(s1==s2);//false
		System.out.println(s1.toUpperCase());//KIRAN
		System.out.println(s2.toLowerCase());//pavan
		System.out.println(s1.startsWith("ki"));//true
		System.out.println(s2.endsWith("n"));//true
		System.out.println(s1.equals(s2));//false
		System.out.println(s1.compareTo(s3));//1
		System.out.println(s1+s2);//kiran pavan
		System.out.println(s1.concat(s2));//kiran pavan
	
     }
     
     public static void main(String[] args) {
		Test t=new Test();
		t.result();
	}
}
