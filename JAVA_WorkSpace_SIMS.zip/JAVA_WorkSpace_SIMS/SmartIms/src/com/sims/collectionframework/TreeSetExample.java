package com.sims.collectionframework;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetExample {
	void treeSetData() {
		// TreeSet<String> studentName1=new TreeSet<String>();
		ArrayList<String> studentName = new ArrayList<String>();
		System.out.println("student names:");
		studentName.add("muni");
		studentName.add("kiran");
		studentName.add("rajesh");
		studentName.add("madhan");
		studentName.add("kiran");
		studentName.add("123");
		Iterator i = studentName.iterator();
		while (i.hasNext()) {
			System.out.println(i.next());
		}
		System.out.println("final tree set data after removing duplicates:");
		TreeSet<String> studentName1 = new TreeSet<String>();
		studentName1.addAll(studentName);
		System.out.println(studentName1);
//			 Iterator i2 = studentName1.iterator();
//				while (i2.hasNext()) {
//					System.out.println(i2.next());
//				}
	}

	public static void main(String[] args) {
		TreeSetExample hse = new TreeSetExample();
		hse.treeSetData();
	}

}
