package com.sims.collectionframework;

import java.util.HashSet;
import java.util.Iterator;

public class HashSetExample {
   void hashSetData() {
	   HashSet<String> studentName=new HashSet<String>();
	   System.out.println("student names:");
	    studentName.add("muni");
		studentName.add("kiran");
		studentName.add("rajesh");
		studentName.add("madhan");
		studentName.add("kiran");
		studentName.add("KIRAN  ");
		Iterator i = studentName.iterator();
		while (i.hasNext()) {
			System.out.println(i.next());
		}
   }
   public static void main(String[] args) {
		HashSetExample hse=new HashSetExample();
		hse.hashSetData();
		
		
	}
}
