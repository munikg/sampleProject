package com.sims.collectionframework;

public class Customer {
    int cId;
    String cName;
	public Customer(int cId, String cName) {
		super();
		this.cId = cId;
		this.cName = cName;
		System.out.println(this.cId +"    "+this.cName);
	}
    
    
}
