package com.sims.collectionframework;

import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.plaf.nimbus.AbstractRegionPainter;

public class ArrayListExample {
	void getStudentDetails() {
		ArrayList<String> studentName = new ArrayList<String>();
		studentName.add("muni");
		studentName.add("kiran");
		studentName.add("rajesh");
		studentName.add("madhan");
		studentName.add("bharath");

//		studentName.remove("muni");
//	//	studentName.removeAll(al);//it removes the all data present in array
//
//		studentName.add("muni");
//		studentName.add(2, "krishna");
//		studentName.indexOf();
		System.out.println("printing student data usig iterator :");

//		Iterator i = studentName.iterator();
//		while (i.hasNext()) {
//			System.out.println(i.next());
//		}
		System.out.println("Printing student Marks");
		ArrayList<String> studentMarks = new ArrayList<String>();
		studentMarks.add("50");
		studentMarks.add("59");
		studentMarks.add("60");
		studentMarks.add("79");
		studentMarks.add("100");
//		Iterator i2 = studentMarks.iterator();
//		while (i2.hasNext()) {
//			System.out.println(i2.next());
//		}
		System.out.println("add all method");
		studentName.addAll(studentMarks);
		System.out.println(studentName);
	}

	public static void main(String[] args) {
		ArrayListExample ale = new ArrayListExample();
		ale.getStudentDetails();

	}

}
