package com.sims.collectionframework;

public class Student {
   int id;
   int name;
public Student(int id, int name) {
	super();
	this.id = id;
	this.name = name;
}
   
}
