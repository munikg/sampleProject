package com.sims.collectionframework;

import java.util.Set;
import java.util.TreeMap;

public class TreeMapEx {
	public static void main(String[] args) {
		TreeMap<String,Integer> emp=new TreeMap<String,Integer>();
		emp.put("muni", 100);
		emp.put("kitan", 200);
		Set<String> key=emp.keySet();
		for (String keys : key) {
			System.out.println("name :"+keys+"  ID is :"+emp.get(keys));
			
		}
		
	}

}
