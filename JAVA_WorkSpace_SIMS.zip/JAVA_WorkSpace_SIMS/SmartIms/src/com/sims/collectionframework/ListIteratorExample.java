package com.sims.collectionframework;

import java.util.ArrayList;
import java.util.ListIterator;

public class ListIteratorExample {
	void getdata() {
		ArrayList<String> fruits = new ArrayList<String>();
		fruits.add("banana");
		fruits.add("orange");
		fruits.add("mango");
		System.out.println("printing fruit names forward direction");
		ListIterator<String> li = fruits.listIterator();

		while (li.hasNext()) {
			System.out.println(li.next());

		}
		System.out.println("printing fruit names backward direction");

		while (li.hasPrevious()) {
			System.out.println(li.previous());

		}
	}

	public static void main(String[] args) {
		ListIteratorExample lie = new ListIteratorExample();
		lie.getdata();
	}
}
