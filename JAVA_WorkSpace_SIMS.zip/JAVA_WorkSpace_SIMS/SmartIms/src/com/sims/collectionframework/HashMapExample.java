package com.sims.collectionframework;

import java.util.HashMap;
import java.util.Set;

public class HashMapExample {
   void addDataToHashMap() {
	   HashMap<Integer,String> mobiles= new HashMap<Integer, String>();
	   mobiles.put(1, " ");
	   mobiles.put(null, "samsung");
	   mobiles.put(null, "samsung1");//it will print

	   mobiles.put(3, "oneplus");
	   mobiles.put(4, "iphone");
	  Set<Integer> key= mobiles.keySet();
	  for (Integer keys : key) {
		  System.out.println("Value of "+keys+" is: "+mobiles.get(keys));
	}
   }
   public static void main(String[] args) {
	HashMapExample hme=new HashMapExample();
	hme.addDataToHashMap();
}
}
