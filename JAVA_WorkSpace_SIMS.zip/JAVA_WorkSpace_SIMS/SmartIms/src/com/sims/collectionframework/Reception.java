package com.sims.collectionframework;
import java.util.Scanner;
public class Reception {

     void details() {
    	 Scanner sc =new Scanner(System.in);
    	 System.out.println("Enter Cutomer Id:");
    	 int cId=sc.nextInt();
    	 System.out.println("Enter the customer Name :");
    	 String cName=sc.next();
    	 Customer c=new Customer(cId,cName);
     }
     public static void main(String[] args) {
		Reception r=new Reception();
		r.details();
	}
}
