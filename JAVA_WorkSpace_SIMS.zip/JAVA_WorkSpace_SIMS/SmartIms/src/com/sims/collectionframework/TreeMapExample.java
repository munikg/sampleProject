package com.sims.collectionframework;

import java.util.Set;
import java.util.TreeMap;

public class TreeMapExample {
	void addDataToHashMap() {
		   TreeMap<Integer,String> mobiles= new TreeMap<Integer, String>();
		   mobiles.put(1, "xiomi");
		   mobiles.put(1, "samsung");
		   mobiles.put(3, "oneplus");
		   mobiles.put(4, "iphone");
		  Set<Integer> key= mobiles.keySet();
		  for (Integer keys : key) {
			  System.out.println("Value of "+keys+" is: "+mobiles.get(keys));
		}
	   }
	   public static void main(String[] args) {
		TreeMapExample hme=new TreeMapExample();
		hme.addDataToHashMap();
	}
}
