package com.sims.iostreams;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriterExample {
	void writindDataInFile() {
		try {
			FileWriter fw=new FileWriter("E:\\muni\\sample.txt");
			fw.write("hello file");
			fw.flush();
			fw.close();
			System.out.println("Successfully created");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		FileWriterExample fwe=new FileWriterExample();
		fwe.writindDataInFile();
	}

}
