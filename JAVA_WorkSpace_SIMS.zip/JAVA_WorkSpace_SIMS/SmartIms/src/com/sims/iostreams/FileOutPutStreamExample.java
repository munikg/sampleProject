package com.sims.iostreams;

import java.io.FileOutputStream;

public class FileOutPutStreamExample {
	void fileCreation() {
		try {
		FileOutputStream fout=new FileOutputStream("E:\\kiran\\sample1.txt");
				String str="First file created successfully";
				byte b[]=str.getBytes();
				fout.write(b);
				fout.close();
				System.out.println("file created successfuly");
			
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("folder not created");
		}
		
			
		}
	public static void main(String[] args) {
		FileOutPutStreamExample f=new FileOutPutStreamExample();
		f.fileCreation();
	}
	}


