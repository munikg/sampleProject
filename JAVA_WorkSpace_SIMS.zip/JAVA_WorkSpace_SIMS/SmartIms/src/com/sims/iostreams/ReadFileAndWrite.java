package com.sims.iostreams;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ReadFileAndWrite {
	void pushfile() throws IOException {
		FileInputStream fis=new FileInputStream("E:\\kiran\\sample1.txt");
		FileOutputStream fos=new FileOutputStream("E:\\muni\\sample2.txt");
		int i=0;
		while((i=fis.read())!=-1) {
			fos.write((byte)i);
		}
	fos.close();
	}
	public static void main(String[] args) throws IOException {
		ReadFileAndWrite r=new ReadFileAndWrite();
		r.pushfile();
	}
}

