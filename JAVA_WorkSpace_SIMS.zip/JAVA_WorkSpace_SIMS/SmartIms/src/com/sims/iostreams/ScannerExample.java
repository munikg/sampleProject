package com.sims.iostreams;

import java.util.Scanner;

public class ScannerExample {
	String eName;
	int id;
	String adress;
	 Scanner sc=new Scanner(System.in);
	void getUserData() {
    
     System.out.println("Enter Employee Name :");
      eName=sc.next();
     System.out.println("Enter Id number");
      id=sc.nextInt();
     System.out.println("Enter adress");
      adress=sc.next();
     System.out.println("Employee Name: "+eName);
     System.out.println("Employee Id: "+id);
     System.out.println("Employee Adress: "+adress);
}
	void getPersonalDetails () {
		if(id==101) {
			System.out.println("Enter Email :");
			String s=sc.next();
			
		}
		else {
			System.out.println("user not found");
		}
		
	}
	public static void main(String[] args) {
		ScannerExample se=new ScannerExample();
		se.getUserData();
		se.getPersonalDetails();
	}
}
