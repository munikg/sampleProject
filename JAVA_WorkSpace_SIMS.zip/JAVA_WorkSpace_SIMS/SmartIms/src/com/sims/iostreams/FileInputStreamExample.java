package com.sims.iostreams;

import java.io.FileInputStream;

public class FileInputStreamExample {
	void readFile() {
	try {
		FileInputStream fis=new FileInputStream("E:\\kiran\\sample1.txt");
		 int i;
		 while((i=fis.read())!=-1) {
			 System.out.print((char)i);
		 }
	} catch (Exception e) {
		// TODO: handle exception
		System.out.println(e);
	}
	}
	public static void main(String[] args) {
		FileInputStreamExample fis=new FileInputStreamExample();
		fis.readFile();
		
}
}
