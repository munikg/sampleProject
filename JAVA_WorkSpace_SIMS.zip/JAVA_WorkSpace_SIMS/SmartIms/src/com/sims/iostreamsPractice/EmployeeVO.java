package com.sims.iostreamsPractice;

import java.io.Serializable;

public class EmployeeVO implements Serializable {
  int employeeId;
  String eName;
  int eAge;
public EmployeeVO(int employeeId, String eName, int eAge) {
	super();
	this.employeeId = employeeId;
	this.eName = eName;
	this.eAge = eAge;
}
  
  
}
