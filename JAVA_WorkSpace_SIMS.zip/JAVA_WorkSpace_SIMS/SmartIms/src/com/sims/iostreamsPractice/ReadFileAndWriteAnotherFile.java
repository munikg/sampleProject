package com.sims.iostreamsPractice;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class ReadFileAndWriteAnotherFile {
     void convertFileDataToNewFile() {
    	  try {
			FileInputStream fis=new FileInputStream("E:\\TestFolder\\file1.txt");
			FileOutputStream fos=new FileOutputStream("E:\\TestFolder2\\file1.txt");
			int i;
			while((i=fis.read())!=-1){
				fos.write((byte)i);
			}
			System.out.println("Successfully created");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	  
     }
     public static void main(String[] args) {
		ReadFileAndWriteAnotherFile rf=new ReadFileAndWriteAnotherFile();
		rf.convertFileDataToNewFile();
	}
}
