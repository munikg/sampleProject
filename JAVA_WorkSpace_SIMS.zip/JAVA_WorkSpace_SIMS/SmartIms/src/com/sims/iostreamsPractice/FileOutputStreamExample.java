package com.sims.iostreamsPractice;

import java.io.FileOutputStream;

public class FileOutputStreamExample {
	void fileCreation() {
		
		try {
			for(int i=1;i<=5;i++) {
			FileOutputStream fose = new FileOutputStream("E:\\TestFolder\\file"+i);
			
			String str = "my name is muni kiran";
			byte[] b = str.getBytes();
			fose.write(b);
			fose.flush();
			fose.close();
			

			System.out.println("file"+i+" created successfully");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		FileOutputStreamExample fos = new FileOutputStreamExample();
		fos.fileCreation();
	}

}
