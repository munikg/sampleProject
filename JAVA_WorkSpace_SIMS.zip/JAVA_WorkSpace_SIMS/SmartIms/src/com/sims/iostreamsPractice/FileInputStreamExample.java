package com.sims.iostreamsPractice;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class FileInputStreamExample {
	void readfile() {
		try {
			FileInputStream fis = new FileInputStream("E:\\TestFolder\\file1.txt");
			int i;
			while ((i = fis.read()) != -1) {
				System.out.println((char) i);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		FileInputStreamExample fie = new FileInputStreamExample();
		fie.readfile();
	}
}
