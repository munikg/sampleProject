package com.sims.iostreamsPractice;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.ObjectInputStream;

public class DeSerilization {
	void readDataInObject() {
		
		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream("E:\\EmployeeDetails\\record1.txt"));
			EmployeeVO evo=(EmployeeVO)ois.readObject();
			System.out.println(evo.eName);
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	public static void main(String[] args) {
		DeSerilization ds=new DeSerilization();
		ds.readDataInObject();
	}

}
