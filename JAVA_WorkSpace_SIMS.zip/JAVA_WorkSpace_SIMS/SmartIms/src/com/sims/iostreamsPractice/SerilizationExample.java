package com.sims.iostreamsPractice;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class SerilizationExample {
	void addObjectData() {
		try {

			EmployeeVO evo = new EmployeeVO(101, "madhu", 22);
			FileOutputStream fos = new FileOutputStream("E:\\EmployeeDetails\\record1.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(evo);
			oos.flush();
			oos.close();
			System.out.println("Employee Details Stored Successfully ");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		SerilizationExample se = new SerilizationExample();
		se.addObjectData();

	}
}
