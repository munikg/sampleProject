package com.sims.tasks;

public class CustomerVO {
   String cName;
   int cId;
public String getcName() {
	return cName;
}
public void setcName(String cName) {
	this.cName = cName;
}
public int getcId() {
	return cId;
}
public void setcId(int cId) {
	this.cId = cId;
}
   
}
