package com.sims.tasks;

public class StudentVO {
	int studentName;
	int id;
	int age;
	public StudentVO(int studentName, int id, int age) {
		super();
		this.studentName = studentName;
		this.id = id;
		this.age = age;
	}
	
}
