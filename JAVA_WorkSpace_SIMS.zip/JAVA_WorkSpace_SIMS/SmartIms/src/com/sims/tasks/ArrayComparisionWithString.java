package com.sims.tasks;

public class ArrayComparisionWithString {
    public static void main(String[] args) {
		String []arr=new String[2];
		arr[0]="madhan";
		arr[1]="kiran";
		String s1="kiran";
		String s2=new String("kiran");
		System.out.println(arr[0]==s1);//fasle bcz we have differnt memory;
		System.out.println(arr[1]==s2);//false
		System.out.println(s1==s2);
		System.out.println(s1.equals(s2));
		System.out.println(s1.equals(arr[1]));//compare the data present in objects
		System.out.println(s2.compareTo(arr[1]));
	}
    
}
