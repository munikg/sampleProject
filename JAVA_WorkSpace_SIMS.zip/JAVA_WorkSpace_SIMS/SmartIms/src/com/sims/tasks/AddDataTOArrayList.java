package com.sims.tasks;

import java.util.ArrayList;

public class AddDataTOArrayList {
     void addData() {
    	 for(int i=1;i<5;i++) {
    		 StudentVO svo=new StudentVO(0, 0, 0);
    	 }
    	 ArrayList al=new ArrayList();
     }
}
