package com.sims.tasks;

public class ThreadTest {
	public static void main(String[] args) {
		ThreadExample te=new ThreadExample();
		ThreadExample te1=new ThreadExample();

		System.out.println(te.isAlive());
		te.start();
	
		te1.start();


		System.out.println(te.isAlive());
//	   te.suspend();
//	   te.resume();
	
	}

}
