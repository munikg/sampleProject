package com.sims.tasks;

import java.util.ArrayList;
import java.util.HashSet;

public class RemoveDuplicatesInArrayList {
    void remove() {
    	ArrayList<Integer> al=new ArrayList<Integer>();
    	al.add(1);
    	al.add(2);
    	al.add(2);
    	al.add(3);
    	al.add(4);
    	al.add(1,10);//add at particular index
    	System.out.println("Before Removing Duplicates"+al);
    	HashSet<Integer> hs=new HashSet<Integer>();
    	hs.addAll(al);
    	System.out.println("After Removing Duplicates:"+hs);
    }
    public static void main(String[] args) {
		RemoveDuplicatesInArrayList rem=new RemoveDuplicatesInArrayList();
		rem.remove();
	}
}
