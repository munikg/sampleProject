package com.sims.tasks;

public class ReverseOfString {
	void reverseOfString() {
		String str="hello revesre string";
		StringBuffer sb=new StringBuffer(str);
		   System.out.println(sb.reverse());
		   String str1="muni";
		  System.out.println(str1.concat("kiran"));
		  System.out.println(sb.capacity());
		  
		   
		   	}
public static void main(String[] args) {
	ReverseOfString ros=new ReverseOfString();
	ros.reverseOfString();
}
}
