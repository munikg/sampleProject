package com.sims.tasks;

public class Thread2 extends Thread {
	 PrintNumbers pn;
	    Thread2(PrintNumbers pn){
	    	this.pn=pn;
	    }
	    public void run() {
	    	pn.printNumbers(15);
	    }

}
