package com.sims.tasks;

public class Test {
	public static void main(String[] args) {
		PrintNumbers obj = new PrintNumbers();
		Thread1 t1 = new Thread1(obj);
		Thread2 t2 = new Thread2(obj);
		t1.start();
		t1.stop();
		t2.start();

		//t1.setPriority(Thread.MAX_PRIORITY);

		System.out.println(t1.getName());
	}
}
