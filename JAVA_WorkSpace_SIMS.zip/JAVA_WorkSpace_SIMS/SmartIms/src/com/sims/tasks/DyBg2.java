package com.sims.tasks;

public class DyBg2 extends DyBg {

	@Override
	public void m2() {
		// TODO Auto-generated method stub
		System.out.println("Muni");
	}
	public void m1() {
		  System.out.println("From child"); 
	   }
	public static void main(String[] args) {
		DyBg d=new DyBg2();
		d.m1();
	}
	

}
