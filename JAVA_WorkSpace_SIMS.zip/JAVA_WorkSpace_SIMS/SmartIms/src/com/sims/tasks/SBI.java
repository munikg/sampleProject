package com.sims.tasks;

public class SBI {
	void totalamount() {
		System.out.println("Welcome to Sbi");
		int amount=10000;
		int intrest=3;
		int periodOfTime=4;
		double total=(amount*intrest*periodOfTime)/100;
		System.out.println("Total amount is :"+(total+amount));
		
	}
     
}
