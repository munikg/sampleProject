package com.sims.tasks;

import java.util.Scanner;

public class InterestCalculation {
	int Amount;
	int time;
	int intrest;

	void interestCalculation() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Amount Of money U want : ");
		Amount = sc.nextInt();
		System.out.println("Enter The Time :");
		time = sc.nextInt();
		System.out.println(" Enter Intrest is");
		intrest =sc.nextInt();
		System.out.println("Your Amount Is :" + Amount);
		System.out.println("Your Intrest is :" + intrest);
		System.out.println("your Time Period :" + time);
		System.out.println("Your Final intrest is: " + (Amount * intrest * time) / 100);
	
	}
	public static void main(String[] args) {
		InterestCalculation ic=new InterestCalculation();
		ic.interestCalculation();
	}
}
