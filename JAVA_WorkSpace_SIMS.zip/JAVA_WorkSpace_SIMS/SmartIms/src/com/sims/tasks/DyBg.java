package com.sims.tasks;

public abstract class DyBg {
   public void m1() {
	  System.out.println("From m1"); 
   }
   public abstract void m2();
}
