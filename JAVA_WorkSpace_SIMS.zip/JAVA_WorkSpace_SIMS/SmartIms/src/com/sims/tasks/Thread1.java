package com.sims.tasks;

public class Thread1 extends Thread {
    PrintNumbers pn=new PrintNumbers();
    Thread1(PrintNumbers pn){
    	this.pn=pn;
    }
     public void run() {
    	pn.printNumbers(10);
    }
}
