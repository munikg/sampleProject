package com.sims.tasks;

import java.util.ArrayList;
import java.util.Collections;

public class ReverssOfArrayList {
	void revese() {
		ArrayList<Object> al = new ArrayList<Object>();
		al.add("kiran");
		al.add(1223);
		al.add("muni");
		System.out.println("before reversing :" + al);
		Collections.reverse(al);
		System.out.println("After reversing :" + al);

	}

	public static void main(String[] args) {
		ReverssOfArrayList ral = new ReverssOfArrayList();
		ral.revese();
	}
}
