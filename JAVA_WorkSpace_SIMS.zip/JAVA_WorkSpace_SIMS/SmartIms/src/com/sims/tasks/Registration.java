package com.sims.tasks;

public class Registration {
	CustomerVO cvo=new CustomerVO();
	Service s=new Service();
    void registration() {
    	cvo.setcId(101);
    	cvo.setcName("muni");
    	s.getScreenData(cvo);
    }
    public static void main(String[] args) {
		Registration rgstr=new Registration();
		rgstr.registration();
	}
}
