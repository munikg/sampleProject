package com.sims.tasks;

import java.util.Arrays;

public class SortArrayData {
	void sort() {
		int[] arr = { 1, 6, 2, 8, 3, 9, 0,2 };
		Arrays.sort(arr);
		System.out.println("array data after sorting :");
		for (int i : arr) {

			System.out.println(i);
		}

	}

	public static void main(String[] args) {
		SortArrayData sad = new SortArrayData();
		sad.sort();
	}
}
