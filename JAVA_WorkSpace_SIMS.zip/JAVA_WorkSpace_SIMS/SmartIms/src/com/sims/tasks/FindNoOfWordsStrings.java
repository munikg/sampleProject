package com.sims.tasks;

import java.util.StringTokenizer;

public class FindNoOfWordsStrings {

	void m1() {
		int count = 0;
		String str = "java extensive practice";
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) != ' ') {
				count++;
			}
		}
		StringTokenizer St = new StringTokenizer(str, " ");
		System.out.println("Word present in String :" + St.countTokens());
		System.out.println("The no of Characters present  string is:" + count);

	}

	public static void main(String[] args) {
		FindNoOfWordsStrings fnw = new FindNoOfWordsStrings();
		fnw.m1();
	}

}
