package com.sims.tasks;

public class PrintNumbers {
	synchronized void printNumbers(int n) {

		try {
			for (int i = 0; i <= n; i++) {
				System.out.println("value Of i is: " + i);
				Thread.sleep(1000);
			}

		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}

}
