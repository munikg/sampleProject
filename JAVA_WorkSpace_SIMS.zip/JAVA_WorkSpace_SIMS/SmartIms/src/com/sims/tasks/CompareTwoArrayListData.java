package com.sims.tasks;

import java.util.ArrayList;

public class CompareTwoArrayListData {
	void compareTwoArrays() {
		String s1="kalyan";
     ArrayList< String> al=new ArrayList<String>();
     al.add("kalyan");
     al.add("ravi");
     al.add("ram");
     System.out.println(s1.compareTo(al.get(0)));
     System.out.println(s1.equals(al.get(0)));
     System.out.println(s1==(al.get(0)));
     ArrayList< String> al1=new ArrayList<String>();
     al1.add("kalyan");
     al1.add("ravi");
     al1.add("ram");
     System.out.println(al1.equals(al));//true
     System.out.println(al1.get(1)==al.get(1));//when compare data  by == we get true if we use == compare to object we get false
	}
	public static void main(String[] args) {
		CompareTwoArrayListData cal=new CompareTwoArrayListData();
		cal.compareTwoArrays();
	}
}
