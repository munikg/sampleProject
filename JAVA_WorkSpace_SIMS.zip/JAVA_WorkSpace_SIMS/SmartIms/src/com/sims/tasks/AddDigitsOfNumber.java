package com.sims.tasks;

public class AddDigitsOfNumber {
	void add() {
		int number = 111;
		int temp1=number;
		int temp;
		int result = 0;

		while (number != 0) {
			temp = number % 10;
			result = result + temp;
			number = number / 10;

		}
		System.out.println("Before adding number :" + temp1);

		System.out.println("After adding each digit :" + result);
	}

	public static void main(String[] args) {
		AddDigitsOfNumber ad = new AddDigitsOfNumber();
		ad.add();
	}
}
