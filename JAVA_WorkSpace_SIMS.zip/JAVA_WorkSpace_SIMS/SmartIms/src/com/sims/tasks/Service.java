package com.sims.tasks;

public class Service {
   void getScreenData(CustomerVO cvo) {
	 System.out.println("customer id :"+cvo.getcId());  
	   System.out.println("customer Name :"+cvo.getcName());
   }
}
