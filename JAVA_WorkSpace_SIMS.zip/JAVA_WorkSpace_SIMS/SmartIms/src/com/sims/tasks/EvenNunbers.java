package com.sims.tasks;

import java.util.Scanner;

public class EvenNunbers {
	void printEvenNunbers() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the starting Range :");
		int n1 = sc.nextInt();
		System.out.println("Enter The  ending range u  want :");
		int n = sc.nextInt();
		int count = 1;
		
		for (int i = n1; i <= n; i++) {
			if (i % 2 == 0) {
				
				System.out.println(i);
                count++;
			}

		}
		System.out.println("No.of Even numbers present in range" + count);
		
	}

	public static void main(String[] args) {
		EvenNunbers en = new EvenNunbers();
		en.printEvenNunbers();
	}
}
