package com.sims.tasks;
import java.util.Scanner;
public class Banks {
	void SelectBank() {
		System.out.println("Select Bank :");
		System.out.println("HDFC ");
		System.out.println("SBI");
	}
	void totalAmountWithIntrest() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Bank Name: ");
		String bankName=sc.next();
		if(bankName.equalsIgnoreCase("Sbi")) {
			SBI sbi=new SBI();
			sbi.totalamount();
		}
		else {
			System.out.println("please select a bank which is provided above..");
		}
	}
	public static void main(String[] args) {
		Banks bank=new Banks();
		bank.SelectBank();
		bank.totalAmountWithIntrest();
	}
}
