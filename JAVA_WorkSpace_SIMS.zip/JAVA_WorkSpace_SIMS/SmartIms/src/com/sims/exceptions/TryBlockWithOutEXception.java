package com.sims.exceptions;

public class TryBlockWithOutEXception {
	int i = 10;
	int j = 5;
	 static int k=10;

	void m1() {
		k=i;
		//System.out.println(k);
		System.out.println("before Exception...");
		try {
			k = i / j;
         System.out.println(k);
		} catch (ArithmeticException e) {
			// TODO: handle exception
			System.out.println(e);
		}
		System.out.println("this line printed when excepti0n handled");
	}

	public static void main(String[] args) {
		TryBlockWithOutEXception twe = new TryBlockWithOutEXception();
		twe.m1();
		System.out.println(((true&&false)||(false&&false))||((true&&true)||(false&&false))&&true);
	}

}
