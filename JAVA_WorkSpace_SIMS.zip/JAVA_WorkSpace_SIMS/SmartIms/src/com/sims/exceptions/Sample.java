package com.sims.exceptions;

public class Sample {
   int i=10;
   int j=0;
   int k;
   //int l;
   void m1() {
	   System.out.println("before Exception...");
	   try {
		  k=i/j; 
		  //l=i/j; try block handles only one problem statement
	   }
	   catch (Exception e) {
		// TODO: handle exception
		   System.out.println(e);
	}
	   System.out.println("this line printed when excepti0n handled");
   }
   public static void main(String[] args) {
	Sample s=new Sample();
	s.m1();
}
  
}
