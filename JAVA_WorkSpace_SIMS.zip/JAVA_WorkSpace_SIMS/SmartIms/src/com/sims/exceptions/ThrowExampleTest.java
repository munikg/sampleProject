package com.sims.exceptions;

import java.io.IOException;

public class ThrowExampleTest {
	ThrowsExample te = new ThrowsExample();

	void m2() {
		try {
			te.m1();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			System.out.println("finally excuted");
		}
		System.out.println("normal flow...");

	}

	public static void main(String[] args) {
		ThrowExampleTest te = new ThrowExampleTest();
		te.m2();

	}
}
