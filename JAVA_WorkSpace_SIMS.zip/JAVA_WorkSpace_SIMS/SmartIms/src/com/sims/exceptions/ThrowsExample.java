package com.sims.exceptions;

import java.io.IOException;

public class ThrowsExample {
	int i=5;
	int j=0;
	int l;
	String a=null;
	int b;
	void m1() throws IOException,ArithmeticException {
		l=i/j;
		a.length();
	}
	
}
