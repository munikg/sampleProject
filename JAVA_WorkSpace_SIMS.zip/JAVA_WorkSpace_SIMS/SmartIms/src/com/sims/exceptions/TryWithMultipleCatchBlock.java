package com.sims.exceptions;

public class TryWithMultipleCatchBlock {
	public static void main(String[] args) {
		String name = null;
		int lenth;
		int a[] = new int[5];
		a[0] = 10;// initialization
		a[1] = 20;
		a[2] = 70;
		a[3] = 40;
		a[4] = 50;
		System.out.println("Before Exception..");
		try {
			a[5] = 20;

		} catch (NullPointerException w) {
			System.out.println(w.getMessage());
		} catch (Exception e) {
			// e.printStackTrace();
			System.out.println(e.getMessage());
		} finally {
			System.out.println("finally Block excuted..");// finally block excuted wether Exception handled or not
		}
		try {
			lenth = name.length();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		System.out.println("After exception Handled..");
	}

}
