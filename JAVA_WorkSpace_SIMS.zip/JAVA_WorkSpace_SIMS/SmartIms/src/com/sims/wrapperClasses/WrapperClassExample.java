package com.sims.wrapperClasses;

public class WrapperClassExample {
	 
   void wrapper() {
	   
	   byte b=10;
	   short s=20;
	   char c='v';
	   int i=10;
	   System.out.println("converting primitive to object :");
	   Integer obj1=i;
	   Byte obj2=b;
	   Character obj3=c;
	   System.out.println(obj1+"  "+obj2+"  "+obj3);
	   System.out.println("converting object to primitive :");
	 int x=obj1;
	 byte y=obj2;
	 char z=obj3;
	 System.out.println(x+"  "+y+"  "+"  "+z);
   }
   public static void main(String[] args) {
	WrapperClassExample wc=new WrapperClassExample();
	wc.wrapper();
   }
}
