package com.sims.collections;

import java.util.ArrayList;
import java.util.Scanner;

public class DeptDetails {
	String dName;
	int id;
	

	void addDept() {

		Scanner sc = new Scanner(System.in);

		ArrayList<Department> dept = new ArrayList<Department>();
		for (int i = 1; i < 2; i++) {

			System.out.println("Enter dept" + i + "name :");
			dName = sc.next();
			//dept.add(dName);
			System.out.println("Enter dept" + i + "id :");
			id = sc.nextInt();
			//dept.add(id);
			Department de = new Department(id, dName);
		}
		TestClass t = new TestClass();
		t.printDept(dept);

	}

}
