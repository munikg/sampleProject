package com.sims.collections;

import java.util.ArrayList;
import java.util.Iterator;

public class TestClass {
   void print(ArrayList<StudentVo> al) {
	 for (StudentVo studentVo : al) {
		System.out.println(studentVo.id+" "+studentVo.name);
	}
   
	}
   void printDept(ArrayList<Department> de) {
		 for (Department d : de) {
			System.out.println(d.deptId+""+d.deptName);
		}
	 }
	}
	

	  