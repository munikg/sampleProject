package com.sims.collections;

import java.util.ArrayList;

public class ArrayListExample {
	void m1() {
        StudentVo s=new StudentVo(101,"muni");

		ArrayList<StudentVo> al = new ArrayList<StudentVo>();
		al.add(s);
		//al.addAll(al);
//		al.add("muni");
//
//		al.add("muni");
//
//		al.add("muni");
//
	
	           
		TestClass t = new TestClass();
		t.print(al);
		DeptDetails de=new DeptDetails();
		de.addDept();
		 
	
		

	}

	public static void main(String[] args) {
		ArrayListExample ale = new ArrayListExample();
		ale.m1();
	}
}
