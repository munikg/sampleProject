package com.sims.collections;

public class StudentVo {
   int id;
   String name;
public StudentVo(int id, String name) {
	super();
	this.id = id;
	this.name = name;
}

   
}
