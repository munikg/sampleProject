package com.sims.compareExample;

import java.util.Comparator;

public class ColorComparator implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		AmazonVO avo1=(AmazonVO)o1;
		AmazonVO avo2=(AmazonVO)o1;
		return avo1.color.compareTo(avo2.color);
	}

}
