package com.sims.compareExample;

import java.util.Comparator;

public class NameComparator implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		EmployeeVO evo1=(EmployeeVO)o1;
		EmployeeVO evo2=(EmployeeVO)o2;
		return evo1.name.compareTo(evo2.name);
	}

}
