package com.sims.compareExample;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class SortingObjects {
	void sortObject() {
		ArrayList al = new ArrayList();
		al.add(new AmazonVO(101, "red", 20000));
		al.add(new AmazonVO(100, "blue", 30990));
		al.add(new AmazonVO(95, "green", 10000));
		System.out.println("Sort by Products Id :");
		Collections.sort(al, new ProductIdComparator());
		Iterator itr1 = al.iterator();
		while (itr1.hasNext()) {
			AmazonVO avo = (AmazonVO) itr1.next();
			System.out.println(avo.productId + " " + avo.cost + " " + avo.color);
		}
		System.out.println("Sort by Products color :");
		Collections.sort(al, new ColorComparator());
		Iterator itr2 = al.iterator();
		while (itr2.hasNext()) {
			AmazonVO avo = (AmazonVO) itr2.next();
			System.out.println(avo.productId + " " + avo.cost + " " + avo.color);
		}
		System.out.println("Sort by Products Cost :");
		Collections.sort(al, new CostComparator());
		Iterator itr3 = al.iterator();
		while (itr3.hasNext()) {
			AmazonVO avo = (AmazonVO) itr3.next();
			System.out.println(avo.productId + " " + avo.cost + " " + avo.color);
		}

	}

	public static void main(String[] args) {
		SortingObjects so = new SortingObjects();
		so.sortObject();
	}

}
