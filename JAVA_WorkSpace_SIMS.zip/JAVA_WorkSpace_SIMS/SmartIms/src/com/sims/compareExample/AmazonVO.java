package com.sims.compareExample;

public class AmazonVO {
	int productId;
	String color;
	int cost;

	public AmazonVO(int productId, String color, int cost) {
		super();
		this.productId = productId;
		this.color = color;
		this.cost = cost;
	}

}
