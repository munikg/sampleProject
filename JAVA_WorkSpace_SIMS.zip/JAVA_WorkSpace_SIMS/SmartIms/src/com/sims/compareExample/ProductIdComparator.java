package com.sims.compareExample;

import java.util.Comparator;

public class ProductIdComparator implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		AmazonVO avo1=(AmazonVO)o1;
		AmazonVO avo2=(AmazonVO)o1;
		if(avo1.productId==avo2.productId)
		return 0;
		else if(avo1.productId>avo2.productId)
		return 1;
		else 
		return -1;
	}

}
