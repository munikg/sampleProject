package com.sims.compareExample;

public class EmployeeVO {
    int id;
    String name;
    int age;
	public EmployeeVO(int id, String name, int age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}
    
    
}
