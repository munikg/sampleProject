package com.sims.compareExample;

import java.util.Comparator;

public class AgeComparator implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		EmployeeVO evo1 = (EmployeeVO) o1;
		EmployeeVO evo2 = (EmployeeVO) o2;

		if (evo1.age == evo2.age)
			return 0;
		else if (evo1.age > evo2.age)
			return 1;
		else
			return -1;
	}

}
