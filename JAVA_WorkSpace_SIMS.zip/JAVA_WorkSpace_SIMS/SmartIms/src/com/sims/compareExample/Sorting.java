package com.sims.compareExample;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class Sorting {
	void sortingOfEmployees() {
		ArrayList al = new ArrayList();
		al.add(new EmployeeVO(101, "muni", 21));
		al.add(new EmployeeVO(108, "vijay", 23));
		al.add(new EmployeeVO(103, "harish", 11));
		System.out.println("Sorting By ID..");
		Collections.sort(al, new IdComparator());
		Iterator itr1 = al.iterator();
		while (itr1.hasNext()) {
			EmployeeVO evo = (EmployeeVO) itr1.next();
			System.out.println(evo.id + " " + evo.name + " " + evo.age);
		}
		System.out.println("Sorting By Name..");
		Collections.sort(al, new NameComparator());
		Iterator itr2 = al.iterator();
		while (itr2.hasNext()) {
			EmployeeVO evo = (EmployeeVO) itr2.next();
			System.out.println(evo.id + " " + evo.name + " " + evo.age);
		}
		System.out.println("Sorting By Age..");
		Collections.sort(al, new AgeComparator());
		Iterator itr3 = al.iterator();
		while (itr3.hasNext()) {
			EmployeeVO evo = (EmployeeVO) itr3.next();
			System.out.println(evo.id + " " + evo.name + " " + evo.age);
		}

	}

	public static void main(String[] args) {
		Sorting s = new Sorting();
		s.sortingOfEmployees();

	}

}
