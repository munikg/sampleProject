package com.sims.action;

import java.util.Scanner;

public class UpdateEmployeeAction {
  void updateRecord() {
	  Scanner sc=new Scanner(System.in);
	  System.out.println("Enter person id to update:");
	  int empId=sc.nextInt();
	  System.out.println("");
  }
}
