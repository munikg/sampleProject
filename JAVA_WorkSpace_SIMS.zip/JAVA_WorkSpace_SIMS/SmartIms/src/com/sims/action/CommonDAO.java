package com.sims.action;

public class CommonDAO {
	DBUtil db = new DBUtil();
	void printScreenValues(PersonVO pvo,VehicleVO vvo,ComputerVO cvo) {
		String res = db.connectDB("oracle");
		if (res.equalsIgnoreCase("success")) {
            System.out.println("Customer Details :");
            System.out.println("------------------");
			System.out.println("PersonID :" + pvo.getId());
			System.out.println("Name     :" + pvo.getName());
			System.out.println("Age      :" + pvo.getAge());
			System.out.println("Address  :" + pvo.getAddress());
			System.out.println("City     :" + pvo.getCity());
			System.out.println("Salary   :" + pvo.getSalary());
			System.out.println();
			System.out.println("Bike details purchased by "+pvo.getName());
			System.out.println("-------------------");
			System.out.println("Vehicle Name        : "+vvo.getVehicleName());
			System.out.println("Engine speed        : "+vvo.getSpeed());
			System.out.println("Bike Color          : "+vvo.getColor());
			System.out.println();
			System.out.println("computer details");
			System.out.println("-------------------");
			System.out.println("Brand Name : "+cvo.getBrandName());
			System.out.println("Processoor : "+cvo.getProcessor());
			System.out.println("Generation : "+cvo.getGeneration());
			System.out.println("cost       : "+cvo.getCost());

		} else {
			System.out.println("oops!!...database Connection Failed..");
		}
	}
	
}
