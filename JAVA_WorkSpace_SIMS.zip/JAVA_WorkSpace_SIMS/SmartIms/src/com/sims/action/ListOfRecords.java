package com.sims.action;

public class ListOfRecords {
	

	void listOfemployees() {
		EmpDAO eDAO = new EmpDAO();

		eDAO.getListOfRecord();

	}

	public static void main(String[] args) {
		ListOfRecords db = new ListOfRecords();
		db.listOfemployees();
	}

}
