package com.sims.action;

public class CC {
     static String insertSQL="insert into persons values(?,?,?,?,?,?,?)";
     static String deleteSQL="delete from persons where id = ?";
     static String searchSQL="Select * from persons where id=?";
     

}
