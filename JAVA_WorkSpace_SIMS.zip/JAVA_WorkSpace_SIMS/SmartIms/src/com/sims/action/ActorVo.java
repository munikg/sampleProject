package com.sims.action;

import java.sql.Date;
import java.sql.Timestamp;

public class ActorVo {
	int actor_id;
	String first_name;
	Timestamp Last_Update;

	public Timestamp getLast_Update() {
		return Last_Update;
	}

	public void setLast_Update(Timestamp last_Update) {
		Last_Update = last_Update;
	}

	public int getActor_id() {
		return actor_id;
	}

	public void setActor_id(int actor_id) {
		this.actor_id = actor_id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	

}
