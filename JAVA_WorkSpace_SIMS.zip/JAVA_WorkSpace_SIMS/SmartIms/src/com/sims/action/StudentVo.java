package com.sims.action;

import java.io.Serializable;

public class StudentVo implements Serializable {
	transient int id;
	String name;
	String grade;

	public StudentVo(int id, String name, String grade) {
		super();
		this.id = id;
		this.name = name;
		this.grade = grade;
	}

}
