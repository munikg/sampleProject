package com.sims.action;

public class DBUtil {
	String result;

	String connectDB(String dbName) {
		if (dbName.equalsIgnoreCase("oracle")) {
			System.out.println("Oracle Database connection established..");
			result = "success";
		} else {
			// System.out.println("Database connection failed..Try Again");
			result = "fail";
		}
		return result;
	}

}
