package com.sims.action;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class DeSerilizationExample {
	void readObjectData() {
		try {
			ObjectInputStream ois=new ObjectInputStream(new FileInputStream("E:\\muni\\SudentDetails.txt"));
			StudentVo svo=(StudentVo)ois.readObject();
			System.out.println(svo.id+svo.grade);
			ois.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
    public static void main(String[] args) {
		DeSerilizationExample dse=new DeSerilizationExample();
		dse.readObjectData();
	}
}
