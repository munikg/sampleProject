package com.sims.action;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;

public class EmpDAO {
	void insertRecord(PersonVO pvo) {
		Timestamp t = new Timestamp(System.currentTimeMillis());
		try {
	
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "root");
			System.out.println("Connected to Database Successfully");
			PreparedStatement stmt = con.prepareStatement(CC.insertSQL);
			stmt.setInt(1, pvo.getId());
			stmt.setString(2, pvo.getName());
			stmt.setString(3, pvo.getAddress());
			stmt.setString(4, pvo.getCity());
			stmt.setFloat(5, pvo.getSalary());
			stmt.setInt(6, pvo.getAge());
			stmt.setTimestamp(7, t);
			int rs = stmt.executeUpdate();
			if (rs > 0) {
				System.out.println(rs + "  inserted SuccessFully");
			} else {
				System.out.println("Failed to inserte..");
			}
			System.out.println();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deleteEmpRecord(int empId) {
	
		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "root");
			System.out.println("Connected to Database Successfully");

			PreparedStatement stmt1 = con.prepareStatement(CC.searchSQL);
			stmt1.setInt(1, empId);

			ResultSet rs = stmt1.executeQuery();
			if (rs.next()) {
				PreparedStatement stmt = con.prepareStatement(CC.deleteSQL);
				stmt.setInt(1, empId);
				int i = stmt.executeUpdate();

				if (i > 0) {
					System.out.println("Record deleted succesfully with ID :" + empId);
				} else {
					System.out.println(" failed to delete the record with.." + empId);

				}
			}else {
				System.out.println("record not found with id.."+empId);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void searchRecord(int empId) {
		// TODO Auto-generated method stub
		try {
			boolean status = false;
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "root");
			System.out.println("Connected to Database Successfully");
			PreparedStatement stmt = con.prepareStatement(CC.searchSQL);
			stmt.setInt(1, empId);
			ResultSet rs = stmt.executeQuery();

			if (status = rs.next()) {
				System.out.println("ID          :" + rs.getInt(1));
				System.out.println("NAME        :" + rs.getString(2));
				System.out.println("ADDRESS     :" + rs.getString(3));
				System.out.println("CITY        :" + rs.getString(4));
				System.out.println("SALARY      :" + rs.getFloat(5));
				System.out.println("AGE         :" + rs.getInt(6));
				System.out.println("UPDATED TIME:" + rs.getTimestamp(7));
			}else {
			System.out.println("record not found" + empId);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	public void getListOfRecord() {
		ArrayList actorNamesList = new ArrayList();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/training", "root", "root");
	
			System.out.println("Connected to Database Successfully");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from persons ");

			while (rs.next()) {
				PersonVO pv = new PersonVO();
				pv.setId(rs.getInt(1));
				pv.setName(rs.getString(2));
				pv.setAddress(rs.getString(3));
				pv.setCity(rs.getString(4));
				pv.setSalary(rs.getFloat(5));
				pv.setAge(rs.getInt(6));
		        
				actorNamesList.add(pv);
			}
			Iterator itr = actorNamesList.iterator();
			while (itr.hasNext()) {
				PersonVO pvo1 = (PersonVO) itr.next();
				System.out.println(pvo1.getId()+" "+pvo1.getName()+" "+pvo1.getAddress()+"  "+pvo1.getCity()+"  "+pvo1.getSalary()+"  "+pvo1.getAge());
			}

		} catch (Exception e) {
			e.printStackTrace();

		}


	}

}
