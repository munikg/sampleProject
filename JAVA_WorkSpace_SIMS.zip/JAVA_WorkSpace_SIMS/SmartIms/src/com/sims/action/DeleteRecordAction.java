package com.sims.action;

import java.sql.Timestamp;
import java.util.Scanner;

public class DeleteRecordAction {
	EmpDAO edao = new EmpDAO();
	
	void deleteRecord() {
		Timestamp t = new Timestamp(System.currentTimeMillis());
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Emp ID to delete :");
		int empId = sc.nextInt();
		edao.deleteEmpRecord(empId);
	}
	public static void main(String[] args) {
		DeleteRecordAction d = new DeleteRecordAction();
		d.deleteRecord();
	}

}
