package com.sims.action;

import java.util.Scanner;

public class RegistrationAction {
	PersonVO pvo = new PersonVO();
	EmpDAO eDAO = new EmpDAO();

	public void getScreenValues() {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Customer Id :");
		pvo.setId(sc.nextInt());
		System.out.println("Enter Customer Name :");
		pvo.setName(sc.next());
		System.out.println("Enter Customer Address :");
		pvo.setAddress(sc.next());
		System.out.println("Enter Customer city :");
		pvo.setCity(sc.next());
		System.out.println("Enter Customer Salary :");
		pvo.setSalary(sc.nextFloat());
		System.out.println("Enter Customer Age :");
		pvo.setAge(sc.nextInt());
		eDAO.insertRecord(pvo);
		
		
	}

	public static void main(String[] args) {
		RegistrationAction ra = new RegistrationAction();
		ra.getScreenValues();
	}

}
