package com.sims.action;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Timestamp;

class PrepStmtExample {
	// String dbURL = "jdbc:mysql://localhost:3306/training";
	String username = "root";
	String password = "root";

	void m1() {
		Timestamp t = new Timestamp(System.currentTimeMillis());
		try {
			System.out.println("Chenna");
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root", "root");
			
			System.out.println("Connected to Database Successfully");
			// String sql="insert into actor values(default,?,?,?)";
			/*PreparedStatement stmt = con.prepareStatement("insert into actor values(default,?,?,?)",
					Statement.RETURN_GENERATED_KEYS);*/
			PreparedStatement stmt = con.prepareStatement("insert into actor values(default,?,?,?)",
					Statement.RETURN_GENERATED_KEYS);

			stmt.setString(1, "chenna");
			stmt.setString(2, "uppu");
			stmt.setTimestamp(3, t);
			int rs = stmt.executeUpdate();
			System.out.println(rs + " record inserted Sucessfully");
			//ResultSet ri = stmt.getGeneratedKeys();
			//ri.next();
			//int autogenatedId = ri.getInt(1);

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		PrepStmtExample pse = new PrepStmtExample();
		pse.m1();
	}
}