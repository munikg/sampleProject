package com.sims.action;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class SerilazableExample {
       void result() {
    	  
		try {
			StudentVo s=new StudentVo(101, "madhan", "12th grade");
			 FileOutputStream fos = new FileOutputStream("E:\\muni\\SudentDetails.txt");
			 ObjectOutputStream oos=new ObjectOutputStream(fos);
			 oos.writeObject(s);
			 oos.flush();
			 oos.close();
			 System.out.println("Successfully done");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	  
    	   
       }
       public static void main(String[] args) {
		SerilazableExample o=new SerilazableExample();
		o.result();
	}
}
