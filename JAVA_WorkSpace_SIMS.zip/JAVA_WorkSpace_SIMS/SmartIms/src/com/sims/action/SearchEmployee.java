package com.sims.action;

import java.util.Scanner;

public class SearchEmployee {
	EmpDAO edao = new EmpDAO();
	void searchRecords(){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Emp ID to Search :");
		int empId = sc.nextInt();
		edao.searchRecord(empId);

	}
public static void main(String[] args) {
	SearchEmployee se=new SearchEmployee();
	se.searchRecords();
}
}
