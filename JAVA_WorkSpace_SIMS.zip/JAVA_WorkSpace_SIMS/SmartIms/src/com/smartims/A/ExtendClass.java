package com.smartims.A;

public class ExtendClass extends AbstractClassEX {

	@Override
	public void m1() {
		System.out.println("From Extend Class");
		
	}
	public void m2() {
		super.m2();
		   System.out.println("From m2 extend class");
	   }
	public static void main(String[] args) {
		AbstractClassEX ae=new ExtendClass();
		ae.m1();
		ae.m2();
	}

}
