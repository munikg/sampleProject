package com.smartims.A;

public class C2 extends C1 {
	void m1() {
	System.out.println(a);
	System.out.println(b);
	//System.out.println(c);
	System.out.println(d);
	}
  
}
