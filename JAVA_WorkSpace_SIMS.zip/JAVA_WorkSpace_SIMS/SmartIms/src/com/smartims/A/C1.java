package com.smartims.A;

public class C1 {
	int a=10;
	public int b=20;
	private int c=30;
	protected int d=40;
}

