package com.smartims.A;

public abstract class AbstractClassEX {
   public abstract void m1();
   public void m2() {
	   System.out.println("From m2 abstract class");
   }
}
