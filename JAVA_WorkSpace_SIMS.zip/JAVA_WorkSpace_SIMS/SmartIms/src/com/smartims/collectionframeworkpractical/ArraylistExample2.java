package com.smartims.collectionframeworkpractical;

import java.util.ArrayList;

public class ArraylistExample2 {
	ArrayList<String> getStudentDetails() {
		ArrayList<String> studentName = new ArrayList<String>();
		studentName.add("muni");
		studentName.add("kiran");
		studentName.add("rajesh");
		studentName.add("madhan");
		return studentName;

	}
}
