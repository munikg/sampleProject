package com.smartims.collectionframeworkpractical;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;

public class StudentData {
	

	void AddStudentNames() {
		Scanner sc = new Scanner(System.in);
		ArrayList<String> sName = new ArrayList<String>();
		int size;
		for (int i = 1; i <= 4; i++) {
			System.out.println("Enter Student" + i + " Names :");
			String s = sc.next();
			sName.add(s);
		}
		
		System.out.println("Student List :");
		System.out.println(sName);
		System.out.println("StudentList After Removing Duplicates :");
       TreeSet ts=new TreeSet();
       ts.addAll(sName);
       System.out.println(ts);
       Iterator itr=ts.iterator();
       while(itr.hasNext()) {
    	   System.out.println(itr.next());
       }
	}

	public static void main(String[] args) {
		StudentData sd = new StudentData();
		sd.AddStudentNames();
	}

}
