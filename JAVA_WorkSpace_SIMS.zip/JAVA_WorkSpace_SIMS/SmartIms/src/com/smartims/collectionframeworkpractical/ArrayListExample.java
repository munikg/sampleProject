package com.smartims.collectionframeworkpractical;

import java.util.ArrayList;
import java.util.ListIterator;

public class ArrayListExample {
	ArraylistExample2 al=new ArraylistExample2();
	void addDataToArray() {
		//al.getStudentDetails();
		ArrayList<String> mobiles = new ArrayList<String>();
		mobiles.add("xiomi");
		mobiles.add("samsung");
		mobiles.add("iphone");
		//mobiles.add(al.addDataToArray());
		ArrayList<String> studentNameList=al.getStudentDetails();
		mobiles.addAll(studentNameList);
		ListIterator<String> l = mobiles.listIterator();
		System.out.println("Elements in array in descending order :");
		while (l.hasNext()) {
			System.out.println(l.next());
		}
		System.out.println("Elements in array in ascending order :");
		while (l.hasPrevious()) {
			System.out.println(l.previous());
		}
		// System.out.println(mobiles);

	}

	public static void main(String[] args) {
		ArrayListExample ale = new ArrayListExample();
		ale.addDataToArray();
	}

}
