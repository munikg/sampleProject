package com.smartims.constructors;

public class SuperExAtMethodEx1 {
 void add() {
	 System.out.println("addition done");
 }

}
