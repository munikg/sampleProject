package com.smartims.constructors;

public class TestSigleton {
   public static void main(String[] args) {
	SingletonEx s=SingletonEx.getInstance();
	SingletonEx t=SingletonEx.getInstance();
	SingletonEx u=SingletonEx.getInstance();
	System.out.println(s);
	System.out.println(t);

}
}
