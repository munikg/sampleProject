package com.smartims.constructors;

public class SingletonEx {
	private static SingletonEx obj=null;
	private SingletonEx() {
		System.out.println("sinleton Object");
	}
	public static SingletonEx getInstance() {
		
	  obj=new SingletonEx();
	  return obj;
	}
	

}
