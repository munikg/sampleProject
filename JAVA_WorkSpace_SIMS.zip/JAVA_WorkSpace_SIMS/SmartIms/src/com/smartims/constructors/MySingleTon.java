package com.smartims.constructors;

public class MySingleTon {
	private static MySingleTon myobj;

	private MySingleTon() {
		System.out.println("I am private constructor");
	}

	public static MySingleTon getInstance() {
		myobj = new MySingleTon();
		return myobj;
	}

	public void getSomething() {
		System.out.println("im help you");
	}

}
