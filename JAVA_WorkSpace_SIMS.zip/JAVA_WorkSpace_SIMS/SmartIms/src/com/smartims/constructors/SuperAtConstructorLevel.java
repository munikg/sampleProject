package com.smartims.constructors;

public class SuperAtConstructorLevel extends SuperAtConstrutorLevel {
	public SuperAtConstructorLevel(){
		super(10);//it is used call constructor of the super class by passing parameters through super
		System.out.println("from b constructor");
	}
	public static void main(String[] args) {
		SuperAtConstructorLevel sc=new SuperAtConstructorLevel();
		}
    
}
