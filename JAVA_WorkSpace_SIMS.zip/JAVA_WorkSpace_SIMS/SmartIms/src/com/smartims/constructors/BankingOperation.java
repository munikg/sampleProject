package com.smartims.constructors;

public class BankingOperation {
	final int accountNumber = 1234;

	BankingOperation() {
		// TODO Auto-generated method stub
		System.out.println("Database connection established successfully..");
	}

	int  withdraw(int withdraw) {
		withdraw=deposit(1000)-withdraw;
		System.out.println("Withdrawing the money in acctNum  " + accountNumber);
		return withdraw;
	}

	int deposit(int total) {
		
		System.out.println("deposit the money in acctNum  " + accountNumber);
		return total;
	}

	 void updateInfo() {
		System.out.println("Information Updated Successfully in acctNum  " + accountNumber);
	}

	public static void main(String[] args) {
		BankingOperation bo = new BankingOperation();
		bo.deposit(1000);
		System.out.println(bo.withdraw(200));
		bo.updateInfo();
	}

}
