package com.smartims.constructors;

public class ThisAtConstrutorLev {
     int empid;
     long sal;
     
	public ThisAtConstrutorLev() {
		this(234567,500000l);
		System.out.println(" default construtor called");
		
	}

	public ThisAtConstrutorLev(int empid, long sal) {
		
		this.empid = empid;
		this.sal = sal;
		System.out.println(empid);
	}
	public static void main(String[] args) {
		ThisAtConstrutorLev tcl=new ThisAtConstrutorLev();
	
	}
     
}
