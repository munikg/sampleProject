package com.smartims.constructors;

public class ThisAtVaribLeLev {
	int a;
	int b;

	public ThisAtVaribLeLev(int a, int b) {
	a = a;
	b = b;

	}
	
	void disp() {
		System.out.println(a);
		System.out.println(b);
	}

	public static void main(String[] args) {
		ThisAtVaribLeLev tvl = new ThisAtVaribLeLev(2,3);
		tvl.disp();

	}

}
