package com.smartims.constructors;

public class EncapsulationEx {
    static double a=0.5;
	private int height;
	private int breadth;
	
	
	public int getHeight() {
		return height;
	}


	public void setHeight(int height) {
		this.height = height;
	}


	public int getBreadth() {
		return breadth;
	}


	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}


	void areaOfTraiangle() {
		System.out.println("area of traingle is :"+this.breadth*this.height*EncapsulationEx.a);
	}
	
    
}
