package com.smartims.constructors;

public class ConstrutorExample {
	String name;
	int age;
	String gender;

	public ConstrutorExample() {
		System.out.println("from default constructor....");
	}

	public ConstrutorExample(String name, int age) {
		this();
		System.out.println("Name is :" + name + " Age is : " + age);
	}
	public ConstrutorExample(String name, int age, String gender) {
		this("kiran",10);
		this.name = name;
		this.age = age;
		this.gender = gender;
		System.out.println("Name is :" + name + " Age is : "+age +"Gender :"+gender);

	}

	public static void main(String[] args) {
		ConstrutorExample c2 = new ConstrutorExample("munikiran", 10,"male");
	}
}
