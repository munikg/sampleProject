package com.smartims.constructors;

public class ThisAtVariableLev2 {
	String name;
	int age;

	public ThisAtVariableLev2(String name, int age) {

		this.name = name;
		this.age = age;

	}

	void disply() {
		System.out.println(name);
		System.out.println(age);
	}

	public static void main(String[] args) {
		ThisAtVariableLev2 tvl = new ThisAtVariableLev2("kiran", 20);
		tvl.disply();
	}

}
