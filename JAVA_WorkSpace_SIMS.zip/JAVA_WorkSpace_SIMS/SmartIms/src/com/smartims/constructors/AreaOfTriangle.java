package com.smartims.constructors;

public class AreaOfTriangle {
	EncapsulationEx ee = new EncapsulationEx();

	public void disply() {
		ee.setBreadth(5);
		ee.setHeight(9);
		ee.areaOfTraiangle();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AreaOfTriangle aot = new AreaOfTriangle();
		aot.disply();

	}

}
