package com.smartims.constructors;

public class SuperEx2 extends SuperEx1 {

	int j=10;

	void m1() {
		System.out.println(super.i+j);
		try {
			int k;
		}catch (Exception e) {
			// TODO: handle exception
		}

	}
	public static void main(String[] args) {
		SuperEx2 se=new SuperEx2();
		se.m1();
	}
	

}
