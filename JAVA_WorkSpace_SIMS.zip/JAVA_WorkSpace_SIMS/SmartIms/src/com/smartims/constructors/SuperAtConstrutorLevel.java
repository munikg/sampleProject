package com.smartims.constructors;

public class SuperAtConstrutorLevel {
	int a;
public SuperAtConstrutorLevel(int a) {
	this.a=a;
	System.out.println("I m from A Constructor");
}
}
