package com.smartims.constructors;

public class SuperEx1    {
 int i=10;
 int j=0;
 void m1() throws ArithmeticException {
	 int k=i/j;
 }

}
