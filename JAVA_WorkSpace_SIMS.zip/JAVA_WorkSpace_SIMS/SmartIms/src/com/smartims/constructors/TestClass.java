package com.smartims.constructors;

public class TestClass {
	 static void test() {
	MySingleTon ms	= MySingleTon.getInstance();
	ms.getSomething();
		 
	}
	public static void main(String[] args) {
		TestClass.test();
		
	}
}
