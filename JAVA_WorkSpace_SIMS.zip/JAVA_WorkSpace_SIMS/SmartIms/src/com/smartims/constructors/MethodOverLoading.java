package com.smartims.constructors;

public class MethodOverLoading {
	String result;

	void login(String phoneNumber) {
		if (phoneNumber.length() == 10) {
			System.out.println("Login successfull");
		} else {
			System.out.println("PhoneNumber is incorrect..please TryAgain");
		}
	}

	void login(String userName, String password) {
		if (userName == null && password != null) {
			System.out.println("Please Enter Username");
		}
		if (userName != null && password == null) {
			System.out.println("Please Enter password");
		}

		if (userName != null && password != null) {
			System.out.println("Login successfull");
		}

		else {
			System.out.println(" please Enter details ");
		}
	}

	void login(int pin) {
		int lengthOfInt = (int) (Math.log10(pin) + 1);
		if (lengthOfInt == 4) {
			System.out.println("login successfull");
		} else {
			System.out.println("incorrect pin");
		}

	}

	public static void main(String[] args) {
		MethodOverLoading m = new MethodOverLoading();
		m.login("hshjsj","123qweasd");
	}

}
