package com.smartims.constructors;

public class C {
  int a=10;
}
