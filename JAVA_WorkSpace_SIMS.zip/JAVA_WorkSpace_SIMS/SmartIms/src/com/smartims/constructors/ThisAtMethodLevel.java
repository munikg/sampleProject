package com.smartims.constructors;

public class ThisAtMethodLevel {
	
    void m1() {
    	System.out.println("m1 method Excuted");
    }
    void m2() {
    	this.m1();
    	System.out.println("m2 method Excuted");
    }
    void m3() {
    	this.m2();
    	System.out.println("m3 method Excuted");
    }
    public static void main(String[] args) {
		ThisAtMethodLevel tml=new ThisAtMethodLevel();
		tml.m3();
	}
}
