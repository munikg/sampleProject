package com.smartims.constructors;

public class SuperExAtMethodEx2 extends SuperExAtMethodEx1   {
	
	void add() {
		super.add();
		System.out.println("Addition done with two numbers this is ooverride");
	}
	 void sub() {
		 System.out.println("Substraction done");
	 }
	 public static void main(String[] args) {
		 SuperExAtMethodEx2 se=new SuperExAtMethodEx2();
		 se.add();
		 se.sub();
		 
	}
}
