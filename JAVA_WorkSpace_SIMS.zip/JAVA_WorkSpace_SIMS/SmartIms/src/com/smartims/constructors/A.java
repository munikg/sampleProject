package com.smartims.constructors;

public class A {
   int a=10;
}
