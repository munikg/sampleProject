package com.smartims.constructors;

public class DButil {
  public String connDB(String dbName) {
	  String result;
	  if(dbName.equalsIgnoreCase("Oracle")) {
		  result="success";
		 System.out.println("Oracle databasde connected");
	  }
	  else {
		  result="failed";
		 System.out.println("connection failed... boss try to reconnect...");
	  }
	return result;
	  
  }
}
