package com.smartims.constructors;

public class BankOperation {
	DButil db=new DButil();
	void withdraw() {
		String res=db.connDB("oracle");
		if(res.equalsIgnoreCase("success")) {
			System.out.println("money withdrawed...");
		}
		else {
			System.out.println(res);
		}
	}
	public static void main(String[] args) {
		BankOperation op= new BankOperation();
		op.withdraw();
	}
}	
	