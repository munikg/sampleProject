package com.smartims.constructors;

public class D extends C{
	int a=20;
	void m1()
	{
		System.out.println(a+a);
	}
	public static void main(String[] args) {
		D d=new D();
		d.m1();
	}
}
