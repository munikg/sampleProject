package com.smartims.constructors;

public class B extends A  {
	int a=20;
	void m1() {
		
		System.out.println(a+super.a);
	}
	public static void main(String[] args) {
		B b=new B();
		b.m1();
	}
   
}
