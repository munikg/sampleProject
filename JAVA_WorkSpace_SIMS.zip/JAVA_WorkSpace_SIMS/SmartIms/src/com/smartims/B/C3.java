package com.smartims.B;

import com.smartims.A.C1;
public class C3 extends C1 {
void m3() {
	//System.out.println(a);//default member
	System.out.println(b);//public member
	//System.out.println(c);//private member
	System.out.println(d);//protected member
}
}
