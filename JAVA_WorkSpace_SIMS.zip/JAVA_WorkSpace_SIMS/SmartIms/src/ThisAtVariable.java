
public class ThisAtVariable {
    int a;
    int b;
	public ThisAtVariable(int c, int d) {
		super();
		a = c;
		b = d;
	}
	
    
}
