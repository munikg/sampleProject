
public class Operations {
	int number1=10;
	int number2=20;
	int result;
	void sum() {
		result=number1+number2;
		System.out.println("sum of Two numbers is :"+ result);
	}
	void substraction() {
		result=number1-number2;
		System.out.println("substractin of two numbers is :"+ result);
	}
	void multiplication() {
		result=number1*number2;
		System.out.println("multiplications of two numbers is :"+ result);
	}
	void division() {
		result=number1/number2;
		System.out.println("division is :"+result);
	}
	void printMyName() {
		System.out.println("Operations done by Kiran...");
	}
	public static void main(String[] args) {
		Operations op=new Operations();
		op.printMyName();
		op.sum();
		op.substraction();
		op.multiplication();
		op.division();
	}
}
