
public class RelationshipEx {
	void m1() {
		System.out.println("m1 method is called");
	}

	void m2() {
		System.out.println(" m2 method is called");
	}
}
