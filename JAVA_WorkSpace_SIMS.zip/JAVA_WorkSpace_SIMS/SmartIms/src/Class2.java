
public class Class2 extends Class1 {
	void printName() {
		System.out.println("kiran");
	}

}
