package Action;
import java.util.Scanner;

import Vo.PersonDetails;
import dao.PersonDao;
public class RegisterPerson {
Scanner sc=new Scanner(System.in);
PersonDetails pd=new PersonDetails();
PersonDao pdao=new PersonDao();
public void registerPerson() {
	System.out.println("Enter Your FullName :");
	String fName=sc.next();
	pd.setFullName(fName);
	System.out.println("Enter Your Phone Number :");
	String phNo=sc.next();
	pd.setPhoneNum(phNo);
	System.out.println("Enter Your Email Id");
	String email=sc.next();
	pd.setEmailId(email);
	pdao.registerPerson(pd);
	System.out.println("Do You Want Add Your FamilyMembers..");
	String opt=sc.next();
	if(opt.equalsIgnoreCase("y")){
		registerPerson();
	}
	else {
		System.out.println("Thank You...");
	}
	
	
}
public static void main(String[] args) {
	RegisterPerson rp=new RegisterPerson();
	rp.registerPerson();
}

}
