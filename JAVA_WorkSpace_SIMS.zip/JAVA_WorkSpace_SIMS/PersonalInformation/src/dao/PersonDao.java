package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;



import Vo.PersonDetails;

public class PersonDao {

	public void registerPerson(PersonDetails pd) {
		// TODO Auto-generated method stub
		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/PersonInfo?useSSL=false", "root", "root");
			System.out.println("Connected to Database Successfully");
			PreparedStatement stmt = con.prepareStatement(cc.CC.registerSql);
			stmt.setString(1, pd.getFullName());
			stmt.setString(2, pd.getPhoneNum());
			stmt.setString(3,pd.getEmailId());
			int rs=stmt.executeUpdate();
			if(rs>0) {
				System.out.println("Inserted Successfully..");
			
			}
			else {
				System.out.println("Failed To Insert..");
			}

		  con.close();
	}
		catch (Exception e) {
			e.printStackTrace();
			
		}
		

}
	
}
