package cc;

public class CC {
	public static String registerSql = "insert into PersonalDetails values(?,?,?)";

}
